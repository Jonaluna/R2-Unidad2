﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1.vista
{
    public partial class FormNumeroPerfecto : Form
    {
        public FormNumeroPerfecto()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Program.formaFunciones.Show();
            Hide();
        }

        private void Arreglos_Click(object sender, EventArgs e)
        {
            int num;


            num = int.Parse(textNumero.Text);

            num = Math.Abs(num);
            if (NumeroPerfecto(num) == 1)
            {
                textResultado.Text = "El numero " + num + " es perfecto ";



            }
            else { textResultado.Text = "El numero " + num + " no es perfecto "; }
        }
        static int NumeroPerfecto(int num)// Este metodo verifica si un numero es perfecto mediante la suma de sus divisores
        {
            int result = 0;
            int sumi = 0;


            for (int i = 1; i < num; i++)
            {
                if (num % i == 0)
                {

                    sumi = sumi + i;
                }

            }


            if (sumi == num)
            {

                result = 1;
            }

            return result;
        }
    }
}
