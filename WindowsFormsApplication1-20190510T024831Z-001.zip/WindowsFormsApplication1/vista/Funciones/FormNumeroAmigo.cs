﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1.vista
{
    public partial class FormNumeroAmigo : Form
    {
        public FormNumeroAmigo()
        {
            InitializeComponent();
        }

        private void Arreglos_Click(object sender, EventArgs e)
        {
            int num1, num2;
            int sum1 = 1, sum2 = 1;
            
            num1 = Convert.ToInt32(textBoxNum1.Text);
          
            num2 = Convert.ToInt32(textBoxNum2.Text);
            sum1 = suma(num1, sum1);
            sum2 = suma(num2, sum2);
            if (num1 == num2)
            {
                textResultado.Text="Los números " + num1 + " y " + num2 + " Si son numeros amigos";
            }
            else if ((sum1 == num2) && (sum2 == num1))
            {
                textResultado.Text = "los numeros " + num1 + " y " + num2 + " Si son numeros amigos";
            }
            else
            {
                textResultado.Text = "Los números " + num1 + " y " + num2 + " No son numeros amigos";
            }
        }
        static int suma(int N, int S)//Este metodo realiza las sumas de los divisores de dos nuemeros dados
        {
            for (int i = 2; i < N; i++)
            {
                if (N % i == 0)
                {
                    S = S + i;
                }
            }
            return S;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Program.formaFunciones.Show();
            Hide();
        }
    }
}
