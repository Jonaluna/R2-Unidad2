﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1.vista.Funciones
{
    public partial class FormCombinatorios : Form
    {
        public FormCombinatorios()
        {
            InitializeComponent();
        }

        private void labelResultado_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Program.formaFunciones.Show();
            Hide();
        }

        private void Arreglos_Click(object sender, EventArgs e)
        {
            int m, n;
          
            m = Int16.Parse(textM.Text);

        
            n = Int16.Parse(textN.Text);

            textResultado.Text=""+ Combinatorio(m, n);
        
        }
        static Double Combinatorio(int m, int n)//Este metodo calcula la combinatoria de la forma m sobre n
        {
            double cmb;
            int part1 = 1, part2 = 1, part3 = 1;
            for (int con = m; con > 0; con--)
            {
                part1 = part1 * con;
            }
            for (int con2 = n; con2 > 0; con2--)
            {
                part2 = part2 * con2;
            }
            int p3 = m - n;
            for (int con2 = p3; con2 > 0; con2--)
            {
                part3 = part3 * con2;
            }

            cmb = part1 / (part2 * part3);

            return cmb;


        }
    }
}
