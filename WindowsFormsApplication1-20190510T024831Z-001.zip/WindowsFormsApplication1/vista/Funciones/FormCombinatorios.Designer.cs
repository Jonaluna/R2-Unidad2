﻿namespace WindowsFormsApplication1.vista.Funciones
{
    partial class FormCombinatorios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormCombinatorios));
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.labelIngresarm = new System.Windows.Forms.Label();
            this.textM = new System.Windows.Forms.TextBox();
            this.labelIngresarN = new System.Windows.Forms.Label();
            this.textN = new System.Windows.Forms.TextBox();
            this.labelResultado = new System.Windows.Forms.Label();
            this.Arreglos = new System.Windows.Forms.Button();
            this.textResultado = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(56, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(243, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "Números combinatorios";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(275, 284);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(63, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // labelIngresarm
            // 
            this.labelIngresarm.AutoSize = true;
            this.labelIngresarm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelIngresarm.Location = new System.Drawing.Point(12, 83);
            this.labelIngresarm.Name = "labelIngresarm";
            this.labelIngresarm.Size = new System.Drawing.Size(182, 16);
            this.labelIngresarm.TabIndex = 2;
            this.labelIngresarm.Text = "Ingresa tu primer número \"m\":";
            // 
            // textM
            // 
            this.textM.Location = new System.Drawing.Point(200, 82);
            this.textM.Name = "textM";
            this.textM.Size = new System.Drawing.Size(100, 20);
            this.textM.TabIndex = 3;
            // 
            // labelIngresarN
            // 
            this.labelIngresarN.AutoSize = true;
            this.labelIngresarN.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelIngresarN.Location = new System.Drawing.Point(12, 124);
            this.labelIngresarN.Name = "labelIngresarN";
            this.labelIngresarN.Size = new System.Drawing.Size(193, 16);
            this.labelIngresarN.TabIndex = 4;
            this.labelIngresarN.Text = "Ingresa tu segundo número \"n:\"";
            // 
            // textN
            // 
            this.textN.Location = new System.Drawing.Point(212, 124);
            this.textN.Name = "textN";
            this.textN.Size = new System.Drawing.Size(100, 20);
            this.textN.TabIndex = 5;
            // 
            // labelResultado
            // 
            this.labelResultado.AutoSize = true;
            this.labelResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelResultado.Location = new System.Drawing.Point(75, 183);
            this.labelResultado.Name = "labelResultado";
            this.labelResultado.Size = new System.Drawing.Size(177, 16);
            this.labelResultado.TabIndex = 6;
            this.labelResultado.Text = "El Combinatorio de m y n es:";
            this.labelResultado.Click += new System.EventHandler(this.labelResultado_Click);
            // 
            // Arreglos
            // 
            this.Arreglos.BackColor = System.Drawing.Color.MistyRose;
            this.Arreglos.Font = new System.Drawing.Font("Lucida Calligraphy", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Arreglos.Location = new System.Drawing.Point(111, 293);
            this.Arreglos.Name = "Arreglos";
            this.Arreglos.Size = new System.Drawing.Size(94, 26);
            this.Arreglos.TabIndex = 15;
            this.Arreglos.Text = "Calcular";
            this.Arreglos.UseVisualStyleBackColor = false;
            this.Arreglos.Click += new System.EventHandler(this.Arreglos_Click);
            // 
            // textResultado
            // 
            this.textResultado.Enabled = false;
            this.textResultado.Location = new System.Drawing.Point(129, 202);
            this.textResultado.Name = "textResultado";
            this.textResultado.Size = new System.Drawing.Size(55, 20);
            this.textResultado.TabIndex = 16;
            // 
            // FormCombinatorios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(334, 331);
            this.ControlBox = false;
            this.Controls.Add(this.textResultado);
            this.Controls.Add(this.Arreglos);
            this.Controls.Add(this.labelResultado);
            this.Controls.Add(this.textN);
            this.Controls.Add(this.labelIngresarN);
            this.Controls.Add(this.textM);
            this.Controls.Add(this.labelIngresarm);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Name = "FormCombinatorios";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormCombinatorios";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label labelIngresarm;
        private System.Windows.Forms.TextBox textM;
        private System.Windows.Forms.Label labelIngresarN;
        private System.Windows.Forms.TextBox textN;
        private System.Windows.Forms.Label labelResultado;
        private System.Windows.Forms.Button Arreglos;
        private System.Windows.Forms.TextBox textResultado;
    }
}