﻿namespace WindowsFormsApplication1.vista
{
    partial class FormNumeroPerfecto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormNumeroPerfecto));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.labelIngNum = new System.Windows.Forms.Label();
            this.textNumero = new System.Windows.Forms.TextBox();
            this.textResultado = new System.Windows.Forms.TextBox();
            this.labelResultado = new System.Windows.Forms.Label();
            this.Arreglos = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(284, 291);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(52, 42);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 17.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(69, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(218, 29);
            this.label1.TabIndex = 1;
            this.label1.Text = "Números perfectos";
            // 
            // labelIngNum
            // 
            this.labelIngNum.AutoSize = true;
            this.labelIngNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelIngNum.Location = new System.Drawing.Point(13, 74);
            this.labelIngNum.Name = "labelIngNum";
            this.labelIngNum.Size = new System.Drawing.Size(121, 16);
            this.labelIngNum.TabIndex = 2;
            this.labelIngNum.Text = "Ingrese un número:";
            // 
            // textNumero
            // 
            this.textNumero.Location = new System.Drawing.Point(160, 74);
            this.textNumero.Name = "textNumero";
            this.textNumero.Size = new System.Drawing.Size(74, 20);
            this.textNumero.TabIndex = 3;
            // 
            // textResultado
            // 
            this.textResultado.Enabled = false;
            this.textResultado.Location = new System.Drawing.Point(88, 142);
            this.textResultado.Multiline = true;
            this.textResultado.Name = "textResultado";
            this.textResultado.Size = new System.Drawing.Size(209, 37);
            this.textResultado.TabIndex = 21;
            // 
            // labelResultado
            // 
            this.labelResultado.AutoSize = true;
            this.labelResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelResultado.Location = new System.Drawing.Point(12, 142);
            this.labelResultado.Name = "labelResultado";
            this.labelResultado.Size = new System.Drawing.Size(70, 16);
            this.labelResultado.TabIndex = 20;
            this.labelResultado.Text = "Resultado";
            // 
            // Arreglos
            // 
            this.Arreglos.BackColor = System.Drawing.Color.MistyRose;
            this.Arreglos.Font = new System.Drawing.Font("Lucida Calligraphy", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Arreglos.Location = new System.Drawing.Point(121, 254);
            this.Arreglos.Name = "Arreglos";
            this.Arreglos.Size = new System.Drawing.Size(94, 26);
            this.Arreglos.TabIndex = 19;
            this.Arreglos.Text = "Verificar";
            this.Arreglos.UseVisualStyleBackColor = false;
            this.Arreglos.Click += new System.EventHandler(this.Arreglos_Click);
            // 
            // FormNumeroPerfecto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(334, 331);
            this.ControlBox = false;
            this.Controls.Add(this.textResultado);
            this.Controls.Add(this.labelResultado);
            this.Controls.Add(this.Arreglos);
            this.Controls.Add(this.textNumero);
            this.Controls.Add(this.labelIngNum);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "FormNumeroPerfecto";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormNumeroPerfecto";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelIngNum;
        private System.Windows.Forms.TextBox textNumero;
        private System.Windows.Forms.TextBox textResultado;
        private System.Windows.Forms.Label labelResultado;
        private System.Windows.Forms.Button Arreglos;
    }
}