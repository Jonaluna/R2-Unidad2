﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1.vista
{
    public partial class FormParametros : Form
    {
        public FormParametros()
        {
            InitializeComponent();
        }

        private void FormParametros_Load(object sender, EventArgs e)
        {

        }

        private void Arreglos_Click(object sender, EventArgs e)
        {

            int numero1, numero2;

            numero1 = Int16.Parse(textBoxNum1.Text);

            numero2 = Int16.Parse(textBoxNum2.Text);
            int[] captura = NumeroMayorResiduo(numero1, numero2);
            Console.WriteLine("El número mayor es: {0}\nEl número menor es: {1}\nResiduo de {0}/{1} es: {2}", captura[2], captura[3], captura[1]);
            Console.WriteLine("El cociente de la división {0}/{1} es: {2}", numero1, numero2, NumeroCociente(numero1, numero2));
            textMayor.Text = "" + captura[2];
            textMenor.Text = "" + captura[3];
            textResiduo.Text = "" + captura[1];
            textCociente.Text = "" + NumeroCociente(numero1, numero2);


        }

        static int[] NumeroMayorResiduo(int numero1, int numero2)//este metodo calcula mediante la resta sucesiva el residuo al igual que verifiaca cual de los dos es mayor
        {
            int[] resultado = new int[4];


            if (numero1 >= numero2)
            {
                resultado[1] = numero1;
                resultado[2] = numero1;
                resultado[3] = numero2;

                while (resultado[1] >= numero2)
                {
                    resultado[1] -= numero2;
                    resultado[0]++;
                }
            }
            else
            {

                resultado[1] = numero2;
                resultado[2] = numero2;
                resultado[3] = numero1;

                while (resultado[1] >= numero1)
                {
                    resultado[1] -= numero1;
                    resultado[0]++;
                }

            }


            return resultado;
        }

        static int NumeroCociente(int numero1, int numero2)//Este metodo calcula el cociennte de dos números dados el primero entre el segundo
        {
            int cociente = 0;

            int residuo = numero1;

            while (residuo >= numero2)
            {
                residuo -= numero2;
                cociente++;
            }
            return cociente;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Program.formaFunciones.Show();
            Hide();
        }
    }
}
