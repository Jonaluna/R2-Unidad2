﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1.vista
{
    public partial class FormFunciones : Form
    {
        public FormFunciones()
        {
            InitializeComponent();
        }

        private void buttonDivision_Click(object sender, EventArgs e)
        {
            Program.formaParametros.Show();
            Hide();
        }

        private void buttonNumPer_Click(object sender, EventArgs e)
        {
            Program.formaNumPerfecto.Show();
            Hide();
        }

        private void buttonNumAm_Click(object sender, EventArgs e)
        {
            Program.formaNumAmigo.Show();
            Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Program.formaCombinatorio.Show();
            Hide();
        }

        private void pictureHome_Click(object sender, EventArgs e)
        {
            Program.formaMenu.Show();
            Hide();
        }
    }
}
