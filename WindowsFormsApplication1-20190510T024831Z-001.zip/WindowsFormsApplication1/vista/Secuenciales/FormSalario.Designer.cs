﻿namespace WindowsFormsApplication1.vista
{
    partial class FormSalario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormSalario));
            this.labelInc = new System.Windows.Forms.Label();
            this.labelIngresar = new System.Windows.Forms.Label();
            this.textSalario = new System.Windows.Forms.TextBox();
            this.labelSA = new System.Windows.Forms.Label();
            this.pictureBoxHome = new System.Windows.Forms.PictureBox();
            this.Calcular = new System.Windows.Forms.Button();
            this.textSalarioAct = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHome)).BeginInit();
            this.SuspendLayout();
            // 
            // labelInc
            // 
            this.labelInc.AutoSize = true;
            this.labelInc.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelInc.Location = new System.Drawing.Point(52, 9);
            this.labelInc.Name = "labelInc";
            this.labelInc.Size = new System.Drawing.Size(258, 25);
            this.labelInc.TabIndex = 0;
            this.labelInc.Text = "INCREMENTO SALARIAL";
            // 
            // labelIngresar
            // 
            this.labelIngresar.AutoSize = true;
            this.labelIngresar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelIngresar.Location = new System.Drawing.Point(12, 107);
            this.labelIngresar.Name = "labelIngresar";
            this.labelIngresar.Size = new System.Drawing.Size(113, 16);
            this.labelIngresar.TabIndex = 1;
            this.labelIngresar.Text = "Ingresa tu salario:";
            // 
            // textSalario
            // 
            this.textSalario.Location = new System.Drawing.Point(170, 103);
            this.textSalario.Name = "textSalario";
            this.textSalario.Size = new System.Drawing.Size(100, 20);
            this.textSalario.TabIndex = 2;
            // 
            // labelSA
            // 
            this.labelSA.AutoSize = true;
            this.labelSA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSA.Location = new System.Drawing.Point(12, 176);
            this.labelSA.Name = "labelSA";
            this.labelSA.Size = new System.Drawing.Size(128, 16);
            this.labelSA.TabIndex = 3;
            this.labelSA.Text = "Tu salario actual es:";
            // 
            // pictureBoxHome
            // 
            this.pictureBoxHome.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHome.Image")));
            this.pictureBoxHome.Location = new System.Drawing.Point(276, 273);
            this.pictureBoxHome.Name = "pictureBoxHome";
            this.pictureBoxHome.Size = new System.Drawing.Size(62, 59);
            this.pictureBoxHome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxHome.TabIndex = 5;
            this.pictureBoxHome.TabStop = false;
            this.pictureBoxHome.Click += new System.EventHandler(this.pictureBoxHome_Click);
            // 
            // Calcular
            // 
            this.Calcular.BackColor = System.Drawing.Color.MistyRose;
            this.Calcular.Font = new System.Drawing.Font("Lucida Calligraphy", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Calcular.Location = new System.Drawing.Point(108, 293);
            this.Calcular.Name = "Calcular";
            this.Calcular.Size = new System.Drawing.Size(94, 26);
            this.Calcular.TabIndex = 20;
            this.Calcular.Text = "Calcular";
            this.Calcular.UseVisualStyleBackColor = false;
            this.Calcular.Click += new System.EventHandler(this.Calcular_Click);
            // 
            // textSalarioAct
            // 
            this.textSalarioAct.Enabled = false;
            this.textSalarioAct.Location = new System.Drawing.Point(170, 176);
            this.textSalarioAct.Name = "textSalarioAct";
            this.textSalarioAct.Size = new System.Drawing.Size(100, 20);
            this.textSalarioAct.TabIndex = 21;
            // 
            // FormSalario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(334, 331);
            this.ControlBox = false;
            this.Controls.Add(this.textSalarioAct);
            this.Controls.Add(this.Calcular);
            this.Controls.Add(this.pictureBoxHome);
            this.Controls.Add(this.labelSA);
            this.Controls.Add(this.textSalario);
            this.Controls.Add(this.labelIngresar);
            this.Controls.Add(this.labelInc);
            this.Name = "FormSalario";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormSalario";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHome)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelInc;
        private System.Windows.Forms.Label labelIngresar;
        private System.Windows.Forms.TextBox textSalario;
        private System.Windows.Forms.Label labelSA;
        private System.Windows.Forms.PictureBox pictureBoxHome;
        private System.Windows.Forms.Button Calcular;
        private System.Windows.Forms.TextBox textSalarioAct;
    }
}