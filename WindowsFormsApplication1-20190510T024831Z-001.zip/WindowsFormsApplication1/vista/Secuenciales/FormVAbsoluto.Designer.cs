﻿namespace WindowsFormsApplication1.vista
{
    partial class FormVAbsoluto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormVAbsoluto));
            this.labelVAbs = new System.Windows.Forms.Label();
            this.labelNum = new System.Windows.Forms.Label();
            this.textNumero = new System.Windows.Forms.TextBox();
            this.labelVA = new System.Windows.Forms.Label();
            this.pictureBoxHome = new System.Windows.Forms.PictureBox();
            this.Calcular = new System.Windows.Forms.Button();
            this.textValAbso = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHome)).BeginInit();
            this.SuspendLayout();
            // 
            // labelVAbs
            // 
            this.labelVAbs.AutoSize = true;
            this.labelVAbs.Font = new System.Drawing.Font("MV Boli", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelVAbs.Location = new System.Drawing.Point(72, 9);
            this.labelVAbs.Name = "labelVAbs";
            this.labelVAbs.Size = new System.Drawing.Size(185, 25);
            this.labelVAbs.TabIndex = 0;
            this.labelVAbs.Text = "VALOR ABSOLUTO";
            // 
            // labelNum
            // 
            this.labelNum.AutoSize = true;
            this.labelNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNum.Location = new System.Drawing.Point(12, 92);
            this.labelNum.Name = "labelNum";
            this.labelNum.Size = new System.Drawing.Size(118, 16);
            this.labelNum.TabIndex = 1;
            this.labelNum.Text = "Ingresa un número";
            // 
            // textNumero
            // 
            this.textNumero.Location = new System.Drawing.Point(136, 92);
            this.textNumero.Name = "textNumero";
            this.textNumero.Size = new System.Drawing.Size(100, 20);
            this.textNumero.TabIndex = 2;
            // 
            // labelVA
            // 
            this.labelVA.AutoSize = true;
            this.labelVA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelVA.Location = new System.Drawing.Point(107, 155);
            this.labelVA.Name = "labelVA";
            this.labelVA.Size = new System.Drawing.Size(129, 16);
            this.labelVA.TabIndex = 3;
            this.labelVA.Text = "El valor absoluto es:";
            // 
            // pictureBoxHome
            // 
            this.pictureBoxHome.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHome.Image")));
            this.pictureBoxHome.Location = new System.Drawing.Point(267, 268);
            this.pictureBoxHome.Name = "pictureBoxHome";
            this.pictureBoxHome.Size = new System.Drawing.Size(69, 66);
            this.pictureBoxHome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxHome.TabIndex = 5;
            this.pictureBoxHome.TabStop = false;
            this.pictureBoxHome.Click += new System.EventHandler(this.pictureBoxHome_Click);
            // 
            // Calcular
            // 
            this.Calcular.BackColor = System.Drawing.Color.MistyRose;
            this.Calcular.Font = new System.Drawing.Font("Lucida Calligraphy", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Calcular.Location = new System.Drawing.Point(110, 293);
            this.Calcular.Name = "Calcular";
            this.Calcular.Size = new System.Drawing.Size(94, 26);
            this.Calcular.TabIndex = 21;
            this.Calcular.Text = "Calcular";
            this.Calcular.UseVisualStyleBackColor = false;
            this.Calcular.Click += new System.EventHandler(this.Calcular_Click);
            // 
            // textValAbso
            // 
            this.textValAbso.Enabled = false;
            this.textValAbso.Location = new System.Drawing.Point(120, 184);
            this.textValAbso.Name = "textValAbso";
            this.textValAbso.Size = new System.Drawing.Size(100, 20);
            this.textValAbso.TabIndex = 22;
            // 
            // FormVAbsoluto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.NavajoWhite;
            this.ClientSize = new System.Drawing.Size(334, 331);
            this.ControlBox = false;
            this.Controls.Add(this.textValAbso);
            this.Controls.Add(this.Calcular);
            this.Controls.Add(this.pictureBoxHome);
            this.Controls.Add(this.labelVA);
            this.Controls.Add(this.textNumero);
            this.Controls.Add(this.labelNum);
            this.Controls.Add(this.labelVAbs);
            this.Name = "FormVAbsoluto";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormVAbsoluto";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHome)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelVAbs;
        private System.Windows.Forms.Label labelNum;
        private System.Windows.Forms.TextBox textNumero;
        private System.Windows.Forms.Label labelVA;
        private System.Windows.Forms.PictureBox pictureBoxHome;
        private System.Windows.Forms.Button Calcular;
        private System.Windows.Forms.TextBox textValAbso;
    }
}