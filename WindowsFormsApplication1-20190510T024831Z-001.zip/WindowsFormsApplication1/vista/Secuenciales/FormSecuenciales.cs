﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1.vista
{
    public partial class FormSecuenciales : Form
    {
        public FormSecuenciales()
        {
            InitializeComponent();
        }

        private void buttonHipotenusa_Click(object sender, EventArgs e)
        {
            Program.formaHipote.Show();
            Hide();
        }

        private void buttonDivisa_Click(object sender, EventArgs e)
        {
            Program.formaDivisas.Show();
            Hide();
        }

        private void buttonIncremento_Click(object sender, EventArgs e)
        {
            Program.formaSalario.Show();
            Hide();
        }

        private void buttonGanancia_Click(object sender, EventArgs e)
        {
            Program.formaGanancia.Show();
            Hide();
        }

        private void buttonVAbsoluto_Click(object sender, EventArgs e)
        {
            Program.formaValAbsol.Show();
            Hide();
        }

        private void buttonEcuacionC_Click(object sender, EventArgs e)
        {
            Program.formaECuadra.Show();
            Hide();
        }

        private void buttonFCM_Click(object sender, EventArgs e)
        {
            Program.formaFCM.Show();
            Hide();
        }

        private void buttonPresupuesto_Click(object sender, EventArgs e)
        {
            Program.formaPresupuesto.Show();
            Hide();
        }

        private void buttonIMC_Click(object sender, EventArgs e)
        {
            Program.formaIMC.Show();
            Hide();
        }

        private void pictureHOME_Click(object sender, EventArgs e)
        {
            Program.formaMenu.Show();
            Hide();
        }
    }
}
