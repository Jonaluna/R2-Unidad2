﻿namespace WindowsFormsApplication1.vista
{
    partial class FormHipotenusa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormHipotenusa));
            this.label1 = new System.Windows.Forms.Label();
            this.labelA = new System.Windows.Forms.Label();
            this.labelB = new System.Windows.Forms.Label();
            this.labelHip = new System.Windows.Forms.Label();
            this.textA = new System.Windows.Forms.TextBox();
            this.textB = new System.Windows.Forms.TextBox();
            this.pictureBoxHome = new System.Windows.Forms.PictureBox();
            this.Arreglos = new System.Windows.Forms.Button();
            this.textHipo = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHome)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(325, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "CÁLCULO DE LA HIPOTENUSA.";
            // 
            // labelA
            // 
            this.labelA.AutoSize = true;
            this.labelA.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelA.Location = new System.Drawing.Point(17, 76);
            this.labelA.Name = "labelA";
            this.labelA.Size = new System.Drawing.Size(137, 17);
            this.labelA.TabIndex = 1;
            this.labelA.Text = "Ingrese el valor de a";
            // 
            // labelB
            // 
            this.labelB.AutoSize = true;
            this.labelB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelB.Location = new System.Drawing.Point(17, 124);
            this.labelB.Name = "labelB";
            this.labelB.Size = new System.Drawing.Size(130, 16);
            this.labelB.TabIndex = 2;
            this.labelB.Text = "Ingrese el valor de b";
            // 
            // labelHip
            // 
            this.labelHip.AutoSize = true;
            this.labelHip.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelHip.Location = new System.Drawing.Point(20, 179);
            this.labelHip.Name = "labelHip";
            this.labelHip.Size = new System.Drawing.Size(176, 16);
            this.labelHip.TabIndex = 3;
            this.labelHip.Text = "El valor de la hipotenusa es:";
            // 
            // textA
            // 
            this.textA.Location = new System.Drawing.Point(180, 73);
            this.textA.Name = "textA";
            this.textA.Size = new System.Drawing.Size(100, 20);
            this.textA.TabIndex = 4;
            // 
            // textB
            // 
            this.textB.Location = new System.Drawing.Point(180, 119);
            this.textB.Name = "textB";
            this.textB.Size = new System.Drawing.Size(100, 20);
            this.textB.TabIndex = 5;
            // 
            // pictureBoxHome
            // 
            this.pictureBoxHome.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHome.Image")));
            this.pictureBoxHome.Location = new System.Drawing.Point(265, 282);
            this.pictureBoxHome.Name = "pictureBoxHome";
            this.pictureBoxHome.Size = new System.Drawing.Size(72, 50);
            this.pictureBoxHome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxHome.TabIndex = 6;
            this.pictureBoxHome.TabStop = false;
            this.pictureBoxHome.Click += new System.EventHandler(this.pictureBoxHome_Click);
            // 
            // Arreglos
            // 
            this.Arreglos.BackColor = System.Drawing.Color.MistyRose;
            this.Arreglos.Font = new System.Drawing.Font("Lucida Calligraphy", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Arreglos.Location = new System.Drawing.Point(117, 282);
            this.Arreglos.Name = "Arreglos";
            this.Arreglos.Size = new System.Drawing.Size(94, 26);
            this.Arreglos.TabIndex = 17;
            this.Arreglos.Text = "Calcular";
            this.Arreglos.UseVisualStyleBackColor = false;
            this.Arreglos.Click += new System.EventHandler(this.Arreglos_Click);
            // 
            // textHipo
            // 
            this.textHipo.Enabled = false;
            this.textHipo.Location = new System.Drawing.Point(202, 179);
            this.textHipo.Name = "textHipo";
            this.textHipo.Size = new System.Drawing.Size(100, 20);
            this.textHipo.TabIndex = 18;
            // 
            // FormHipotenusa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MistyRose;
            this.ClientSize = new System.Drawing.Size(334, 331);
            this.ControlBox = false;
            this.Controls.Add(this.textHipo);
            this.Controls.Add(this.Arreglos);
            this.Controls.Add(this.pictureBoxHome);
            this.Controls.Add(this.textB);
            this.Controls.Add(this.textA);
            this.Controls.Add(this.labelHip);
            this.Controls.Add(this.labelB);
            this.Controls.Add(this.labelA);
            this.Controls.Add(this.label1);
            this.Name = "FormHipotenusa";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormHipotenusa";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHome)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelA;
        private System.Windows.Forms.Label labelB;
        private System.Windows.Forms.Label labelHip;
        private System.Windows.Forms.TextBox textA;
        private System.Windows.Forms.TextBox textB;
        private System.Windows.Forms.PictureBox pictureBoxHome;
        private System.Windows.Forms.Button Arreglos;
        private System.Windows.Forms.TextBox textHipo;
    }
}