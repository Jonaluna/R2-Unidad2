﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1.vista
{
    public partial class FormPresupuesto : Form
    {
        public FormPresupuesto()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Program.formaSecuenciales.Show();
            Hide();
        }

        private void Calcular_Click(object sender, EventArgs e)
        {
            double presupAnual, presupGinec, presupTraum, presupPedit;


            presupAnual = Double.Parse(textPresupuesto.Text);

            presupGinec = presupAnual * 0.40;
            presupTraum = presupAnual * 0.30;
            presupPedit = presupAnual * 0.30;

            textPresGine.Text = "" + presupGinec;
            textPresPedi.Text = "" + presupPedit;
            textPresTrau.Text = "" + presupTraum;
        }
    }
}
