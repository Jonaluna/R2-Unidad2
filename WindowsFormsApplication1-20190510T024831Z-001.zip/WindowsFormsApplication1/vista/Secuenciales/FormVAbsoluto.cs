﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1.vista
{
    public partial class FormVAbsoluto : Form
    {
        public FormVAbsoluto()
        {
            InitializeComponent();
        }

        private void pictureBoxHome_Click(object sender, EventArgs e)
        {
            Program.formaSecuenciales.Show();
            Hide();
        }

        private void Calcular_Click(object sender, EventArgs e)
        {
            double absoluto;
            double numero;

           
            numero = Double.Parse(textNumero.Text);

            absoluto = Math.Abs(numero);

            textValAbso.Text = "" + absoluto;
        }
    }
}
