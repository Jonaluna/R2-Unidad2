﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1.vista
{
    public partial class FormIMC : Form
    {
        public FormIMC()
        {
            InitializeComponent();
        }

        private void pictureBoxHome_Click(object sender, EventArgs e)
        {
            Program.formaSecuenciales.Show();
            Hide();
        }

        private void Arreglos_Click(object sender, EventArgs e)
        {
            double imc, masa, altura;

            
            masa = Double.Parse(textPeso.Text);

            altura = Double.Parse(textAltura.Text);

            imc = masa / (altura * altura);

            textIMC.Text = "" + imc;
        }
    }
}
