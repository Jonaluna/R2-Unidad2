﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1.vista
{
    public partial class FormDivisas : Form
    {
        public FormDivisas()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void FormDivisas_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Arreglos_Click(object sender, EventArgs e)
        {
            double pesos, dolares, euros;

            
            pesos = Double.Parse(textPesos.Text);

            dolares = (pesos / 2) / 19.03;
            euros = dolares * 0.89;

            textDolares.Text = ""+dolares;
            textEuros.Text = "" + euros;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBoxHome_Click(object sender, EventArgs e)
        {
            Program.formaSecuenciales.Show();
            Hide();
        }
    }
}
