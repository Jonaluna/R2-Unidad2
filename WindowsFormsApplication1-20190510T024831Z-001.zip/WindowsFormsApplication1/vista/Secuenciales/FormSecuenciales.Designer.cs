﻿namespace WindowsFormsApplication1.vista
{
    partial class FormSecuenciales
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormSecuenciales));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonDivisa = new System.Windows.Forms.Button();
            this.buttonVAbsoluto = new System.Windows.Forms.Button();
            this.buttonFCM = new System.Windows.Forms.Button();
            this.buttonIncremento = new System.Windows.Forms.Button();
            this.buttonEcuacionC = new System.Windows.Forms.Button();
            this.buttonPresupuesto = new System.Windows.Forms.Button();
            this.buttonGanancia = new System.Windows.Forms.Button();
            this.buttonHipotenusa = new System.Windows.Forms.Button();
            this.buttonIMC = new System.Windows.Forms.Button();
            this.pictureHOME = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureHOME)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-4, -2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(441, 418);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.LightCyan;
            this.label1.Font = new System.Drawing.Font("Lucida Calligraphy", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(94, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(238, 31);
            this.label1.TabIndex = 1;
            this.label1.Text = "SECUENCIALES";
            // 
            // buttonDivisa
            // 
            this.buttonDivisa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.buttonDivisa.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonDivisa.Location = new System.Drawing.Point(12, 102);
            this.buttonDivisa.Name = "buttonDivisa";
            this.buttonDivisa.Size = new System.Drawing.Size(129, 36);
            this.buttonDivisa.TabIndex = 2;
            this.buttonDivisa.Text = "CAMBIO DE DIVISAS";
            this.buttonDivisa.UseVisualStyleBackColor = false;
            this.buttonDivisa.Click += new System.EventHandler(this.buttonDivisa_Click);
            // 
            // buttonVAbsoluto
            // 
            this.buttonVAbsoluto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.buttonVAbsoluto.Font = new System.Drawing.Font("Microsoft JhengHei UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonVAbsoluto.Location = new System.Drawing.Point(12, 173);
            this.buttonVAbsoluto.Name = "buttonVAbsoluto";
            this.buttonVAbsoluto.Size = new System.Drawing.Size(129, 36);
            this.buttonVAbsoluto.TabIndex = 3;
            this.buttonVAbsoluto.Text = "VALOR ABSOLUTO";
            this.buttonVAbsoluto.UseVisualStyleBackColor = false;
            this.buttonVAbsoluto.Click += new System.EventHandler(this.buttonVAbsoluto_Click);
            // 
            // buttonFCM
            // 
            this.buttonFCM.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.buttonFCM.Font = new System.Drawing.Font("Microsoft JhengHei UI", 7.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonFCM.Location = new System.Drawing.Point(12, 245);
            this.buttonFCM.Name = "buttonFCM";
            this.buttonFCM.Size = new System.Drawing.Size(129, 39);
            this.buttonFCM.TabIndex = 4;
            this.buttonFCM.Text = "FRECUENCIA CARDIACA ";
            this.buttonFCM.UseVisualStyleBackColor = false;
            this.buttonFCM.Click += new System.EventHandler(this.buttonFCM_Click);
            // 
            // buttonIncremento
            // 
            this.buttonIncremento.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.buttonIncremento.Font = new System.Drawing.Font("Microsoft JhengHei UI", 7.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonIncremento.Location = new System.Drawing.Point(147, 102);
            this.buttonIncremento.Name = "buttonIncremento";
            this.buttonIncremento.Size = new System.Drawing.Size(129, 36);
            this.buttonIncremento.TabIndex = 5;
            this.buttonIncremento.Text = "INCREMENTO SALARIAL";
            this.buttonIncremento.UseVisualStyleBackColor = false;
            this.buttonIncremento.Click += new System.EventHandler(this.buttonIncremento_Click);
            // 
            // buttonEcuacionC
            // 
            this.buttonEcuacionC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.buttonEcuacionC.Font = new System.Drawing.Font("Microsoft JhengHei UI", 7.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonEcuacionC.Location = new System.Drawing.Point(146, 173);
            this.buttonEcuacionC.Name = "buttonEcuacionC";
            this.buttonEcuacionC.Size = new System.Drawing.Size(128, 36);
            this.buttonEcuacionC.TabIndex = 6;
            this.buttonEcuacionC.Text = "ECUACIÓN CUADRÁTICA";
            this.buttonEcuacionC.UseVisualStyleBackColor = false;
            this.buttonEcuacionC.Click += new System.EventHandler(this.buttonEcuacionC_Click);
            // 
            // buttonPresupuesto
            // 
            this.buttonPresupuesto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.buttonPresupuesto.Font = new System.Drawing.Font("Microsoft JhengHei UI", 7.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPresupuesto.Location = new System.Drawing.Point(147, 245);
            this.buttonPresupuesto.Name = "buttonPresupuesto";
            this.buttonPresupuesto.Size = new System.Drawing.Size(128, 39);
            this.buttonPresupuesto.TabIndex = 7;
            this.buttonPresupuesto.Text = "PRESUPUESTO HOSPITAL";
            this.buttonPresupuesto.UseVisualStyleBackColor = false;
            this.buttonPresupuesto.Click += new System.EventHandler(this.buttonPresupuesto_Click);
            // 
            // buttonGanancia
            // 
            this.buttonGanancia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.buttonGanancia.Font = new System.Drawing.Font("Microsoft JhengHei UI", 7.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonGanancia.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonGanancia.Location = new System.Drawing.Point(295, 102);
            this.buttonGanancia.Name = "buttonGanancia";
            this.buttonGanancia.Size = new System.Drawing.Size(128, 36);
            this.buttonGanancia.TabIndex = 8;
            this.buttonGanancia.Text = "GANANCIA DE ARTICULO";
            this.buttonGanancia.UseVisualStyleBackColor = false;
            this.buttonGanancia.Click += new System.EventHandler(this.buttonGanancia_Click);
            // 
            // buttonHipotenusa
            // 
            this.buttonHipotenusa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.buttonHipotenusa.Font = new System.Drawing.Font("Microsoft JhengHei UI", 7.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonHipotenusa.Location = new System.Drawing.Point(295, 173);
            this.buttonHipotenusa.Name = "buttonHipotenusa";
            this.buttonHipotenusa.Size = new System.Drawing.Size(128, 36);
            this.buttonHipotenusa.TabIndex = 9;
            this.buttonHipotenusa.Text = "CALCULO DE HIPOTENUSA";
            this.buttonHipotenusa.UseVisualStyleBackColor = false;
            this.buttonHipotenusa.Click += new System.EventHandler(this.buttonHipotenusa_Click);
            // 
            // buttonIMC
            // 
            this.buttonIMC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.buttonIMC.Font = new System.Drawing.Font("Microsoft JhengHei UI", 7.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonIMC.Location = new System.Drawing.Point(295, 245);
            this.buttonIMC.Name = "buttonIMC";
            this.buttonIMC.Size = new System.Drawing.Size(128, 39);
            this.buttonIMC.TabIndex = 10;
            this.buttonIMC.Text = "INDICE DE MASA CORPORAL";
            this.buttonIMC.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonIMC.UseVisualStyleBackColor = false;
            this.buttonIMC.Click += new System.EventHandler(this.buttonIMC_Click);
            // 
            // pictureHOME
            // 
            this.pictureHOME.Image = ((System.Drawing.Image)(resources.GetObject("pictureHOME.Image")));
            this.pictureHOME.Location = new System.Drawing.Point(368, 366);
            this.pictureHOME.Name = "pictureHOME";
            this.pictureHOME.Size = new System.Drawing.Size(69, 50);
            this.pictureHOME.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureHOME.TabIndex = 11;
            this.pictureHOME.TabStop = false;
            this.pictureHOME.Click += new System.EventHandler(this.pictureHOME_Click);
            // 
            // FormSecuenciales
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(435, 417);
            this.ControlBox = false;
            this.Controls.Add(this.pictureHOME);
            this.Controls.Add(this.buttonIMC);
            this.Controls.Add(this.buttonHipotenusa);
            this.Controls.Add(this.buttonGanancia);
            this.Controls.Add(this.buttonPresupuesto);
            this.Controls.Add(this.buttonEcuacionC);
            this.Controls.Add(this.buttonIncremento);
            this.Controls.Add(this.buttonFCM);
            this.Controls.Add(this.buttonVAbsoluto);
            this.Controls.Add(this.buttonDivisa);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "FormSecuenciales";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormSecuenciales";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureHOME)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonDivisa;
        private System.Windows.Forms.Button buttonVAbsoluto;
        private System.Windows.Forms.Button buttonFCM;
        private System.Windows.Forms.Button buttonIncremento;
        private System.Windows.Forms.Button buttonEcuacionC;
        private System.Windows.Forms.Button buttonPresupuesto;
        private System.Windows.Forms.Button buttonGanancia;
        private System.Windows.Forms.Button buttonHipotenusa;
        private System.Windows.Forms.Button buttonIMC;
        private System.Windows.Forms.PictureBox pictureHOME;
    }
}