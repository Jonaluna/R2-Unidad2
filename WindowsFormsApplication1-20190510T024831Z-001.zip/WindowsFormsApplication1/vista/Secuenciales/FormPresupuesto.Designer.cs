﻿namespace WindowsFormsApplication1.vista
{
    partial class FormPresupuesto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormPresupuesto));
            this.label1 = new System.Windows.Forms.Label();
            this.labelIngresar = new System.Windows.Forms.Label();
            this.textPresupuesto = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.labelPGin = new System.Windows.Forms.Label();
            this.labelPTr = new System.Windows.Forms.Label();
            this.labelPPed = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Calcular = new System.Windows.Forms.Button();
            this.textPresGine = new System.Windows.Forms.TextBox();
            this.textPresTrau = new System.Windows.Forms.TextBox();
            this.textPresPedi = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(79, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(194, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "PRESUPUESTOS";
            // 
            // labelIngresar
            // 
            this.labelIngresar.AutoSize = true;
            this.labelIngresar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelIngresar.Location = new System.Drawing.Point(12, 81);
            this.labelIngresar.Name = "labelIngresar";
            this.labelIngresar.Size = new System.Drawing.Size(131, 16);
            this.labelIngresar.TabIndex = 1;
            this.labelIngresar.Text = "Ingrese presupuesto";
            // 
            // textPresupuesto
            // 
            this.textPresupuesto.Location = new System.Drawing.Point(173, 77);
            this.textPresupuesto.Name = "textPresupuesto";
            this.textPresupuesto.Size = new System.Drawing.Size(100, 20);
            this.textPresupuesto.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(72, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(214, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "para Ginecologia,Traumatología y Pediatria.";
            // 
            // labelPGin
            // 
            this.labelPGin.AutoSize = true;
            this.labelPGin.Location = new System.Drawing.Point(13, 144);
            this.labelPGin.Name = "labelPGin";
            this.labelPGin.Size = new System.Drawing.Size(166, 13);
            this.labelPGin.TabIndex = 4;
            this.labelPGin.Text = "El presupuesto de ginecologia es:";
            // 
            // labelPTr
            // 
            this.labelPTr.AutoSize = true;
            this.labelPTr.Location = new System.Drawing.Point(12, 179);
            this.labelPTr.Name = "labelPTr";
            this.labelPTr.Size = new System.Drawing.Size(177, 13);
            this.labelPTr.TabIndex = 5;
            this.labelPTr.Text = "El presupuesto de traumatología es:";
            // 
            // labelPPed
            // 
            this.labelPPed.AutoSize = true;
            this.labelPPed.Location = new System.Drawing.Point(16, 211);
            this.labelPPed.Name = "labelPPed";
            this.labelPPed.Size = new System.Drawing.Size(152, 13);
            this.labelPPed.TabIndex = 6;
            this.labelPPed.Text = "El presupuesto de pediatria es:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(268, 281);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(67, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Calcular
            // 
            this.Calcular.BackColor = System.Drawing.Color.MistyRose;
            this.Calcular.Font = new System.Drawing.Font("Lucida Calligraphy", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Calcular.Location = new System.Drawing.Point(111, 281);
            this.Calcular.Name = "Calcular";
            this.Calcular.Size = new System.Drawing.Size(94, 26);
            this.Calcular.TabIndex = 19;
            this.Calcular.Text = "Calcular";
            this.Calcular.UseVisualStyleBackColor = false;
            this.Calcular.Click += new System.EventHandler(this.Calcular_Click);
            // 
            // textPresGine
            // 
            this.textPresGine.Enabled = false;
            this.textPresGine.Location = new System.Drawing.Point(192, 141);
            this.textPresGine.Name = "textPresGine";
            this.textPresGine.Size = new System.Drawing.Size(100, 20);
            this.textPresGine.TabIndex = 20;
            // 
            // textPresTrau
            // 
            this.textPresTrau.Enabled = false;
            this.textPresTrau.Location = new System.Drawing.Point(192, 176);
            this.textPresTrau.Name = "textPresTrau";
            this.textPresTrau.Size = new System.Drawing.Size(100, 20);
            this.textPresTrau.TabIndex = 21;
            // 
            // textPresPedi
            // 
            this.textPresPedi.Enabled = false;
            this.textPresPedi.Location = new System.Drawing.Point(192, 211);
            this.textPresPedi.Name = "textPresPedi";
            this.textPresPedi.Size = new System.Drawing.Size(100, 20);
            this.textPresPedi.TabIndex = 22;
            // 
            // FormPresupuesto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(334, 331);
            this.ControlBox = false;
            this.Controls.Add(this.textPresPedi);
            this.Controls.Add(this.textPresTrau);
            this.Controls.Add(this.textPresGine);
            this.Controls.Add(this.Calcular);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.labelPPed);
            this.Controls.Add(this.labelPTr);
            this.Controls.Add(this.labelPGin);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textPresupuesto);
            this.Controls.Add(this.labelIngresar);
            this.Controls.Add(this.label1);
            this.Name = "FormPresupuesto";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormPresupuesto";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelIngresar;
        private System.Windows.Forms.TextBox textPresupuesto;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labelPGin;
        private System.Windows.Forms.Label labelPTr;
        private System.Windows.Forms.Label labelPPed;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Calcular;
        private System.Windows.Forms.TextBox textPresGine;
        private System.Windows.Forms.TextBox textPresTrau;
        private System.Windows.Forms.TextBox textPresPedi;
    }
}