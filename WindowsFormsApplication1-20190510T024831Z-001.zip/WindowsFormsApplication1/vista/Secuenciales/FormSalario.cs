﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1.vista
{
    public partial class FormSalario : Form
    {
        public FormSalario()
        {
            InitializeComponent();
        }

        private void pictureBoxHome_Click(object sender, EventArgs e)
        {
            Program.formaSecuenciales.Show();
            Hide();
        }

        private void Calcular_Click(object sender, EventArgs e)
        {
            double salario, salarioAum;

            salario = Double.Parse(textSalario.Text);

            salarioAum = (salario * 0.25) + salario;

            textSalarioAct.Text = "" + salarioAum;
        }
    }
}
