﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1.vista
{
    public partial class FormEcuacionC : Form
    {
        public FormEcuacionC()
        {
            InitializeComponent();
        }

        private void pictureBoxHome_Click(object sender, EventArgs e)
        {
            Program.formaSecuenciales.Show();
            Hide();
        }

        private void Arreglos_Click(object sender, EventArgs e)
        {
            double a, b, c, x1, x2;

       
            a = Double.Parse(textBoxA.Text);
           
            b = Double.Parse(textBoxB.Text);
            
            c = Double.Parse(textBoxC.Text);

            x1 = (-b + Math.Sqrt(Math.Abs(b * b - (4 * a * c)))) / 2 * a;
            x2 = (-b - Math.Sqrt(Math.Abs(b * b - (4 * a * c)))) / 2 * a;

            textX1.Text = "" + x1;
            textX2.Text = "" + x2;
        }
    }
}
