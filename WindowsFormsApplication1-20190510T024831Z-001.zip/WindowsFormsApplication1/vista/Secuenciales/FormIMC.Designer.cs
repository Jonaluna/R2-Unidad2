﻿namespace WindowsFormsApplication1.vista
{
    partial class FormIMC
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormIMC));
            this.labelIMC = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textPeso = new System.Windows.Forms.TextBox();
            this.labelIngrAltura = new System.Windows.Forms.Label();
            this.textAltura = new System.Windows.Forms.TextBox();
            this.labelIndice = new System.Windows.Forms.Label();
            this.pictureBoxHome = new System.Windows.Forms.PictureBox();
            this.Calcular = new System.Windows.Forms.Button();
            this.textIMC = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHome)).BeginInit();
            this.SuspendLayout();
            // 
            // labelIMC
            // 
            this.labelIMC.AutoSize = true;
            this.labelIMC.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelIMC.Location = new System.Drawing.Point(44, 9);
            this.labelIMC.Name = "labelIMC";
            this.labelIMC.Size = new System.Drawing.Size(244, 26);
            this.labelIMC.TabIndex = 0;
            this.labelIMC.Text = "Índice de masa corporal";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(27, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Ingrese su peso:";
            // 
            // textPeso
            // 
            this.textPeso.Location = new System.Drawing.Point(162, 73);
            this.textPeso.Name = "textPeso";
            this.textPeso.Size = new System.Drawing.Size(100, 20);
            this.textPeso.TabIndex = 2;
            // 
            // labelIngrAltura
            // 
            this.labelIngrAltura.AutoSize = true;
            this.labelIngrAltura.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelIngrAltura.Location = new System.Drawing.Point(30, 131);
            this.labelIngrAltura.Name = "labelIngrAltura";
            this.labelIngrAltura.Size = new System.Drawing.Size(109, 16);
            this.labelIngrAltura.TabIndex = 3;
            this.labelIngrAltura.Text = "Ingrese su altura:";
            // 
            // textAltura
            // 
            this.textAltura.Location = new System.Drawing.Point(162, 131);
            this.textAltura.Name = "textAltura";
            this.textAltura.Size = new System.Drawing.Size(100, 20);
            this.textAltura.TabIndex = 4;
            // 
            // labelIndice
            // 
            this.labelIndice.AutoSize = true;
            this.labelIndice.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelIndice.Location = new System.Drawing.Point(69, 189);
            this.labelIndice.Name = "labelIndice";
            this.labelIndice.Size = new System.Drawing.Size(193, 16);
            this.labelIndice.TabIndex = 5;
            this.labelIndice.Text = "Tu índice de masa corporal es:";
            // 
            // pictureBoxHome
            // 
            this.pictureBoxHome.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHome.Image")));
            this.pictureBoxHome.Location = new System.Drawing.Point(265, 273);
            this.pictureBoxHome.Name = "pictureBoxHome";
            this.pictureBoxHome.Size = new System.Drawing.Size(71, 58);
            this.pictureBoxHome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxHome.TabIndex = 7;
            this.pictureBoxHome.TabStop = false;
            this.pictureBoxHome.Click += new System.EventHandler(this.pictureBoxHome_Click);
            // 
            // Calcular
            // 
            this.Calcular.BackColor = System.Drawing.Color.MistyRose;
            this.Calcular.Font = new System.Drawing.Font("Lucida Calligraphy", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Calcular.Location = new System.Drawing.Point(117, 293);
            this.Calcular.Name = "Calcular";
            this.Calcular.Size = new System.Drawing.Size(94, 26);
            this.Calcular.TabIndex = 18;
            this.Calcular.Text = "Calcular";
            this.Calcular.UseVisualStyleBackColor = false;
            this.Calcular.Click += new System.EventHandler(this.Arreglos_Click);
            // 
            // textIMC
            // 
            this.textIMC.Enabled = false;
            this.textIMC.Location = new System.Drawing.Point(111, 219);
            this.textIMC.Name = "textIMC";
            this.textIMC.Size = new System.Drawing.Size(100, 20);
            this.textIMC.TabIndex = 19;
            // 
            // FormIMC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(334, 331);
            this.ControlBox = false;
            this.Controls.Add(this.textIMC);
            this.Controls.Add(this.Calcular);
            this.Controls.Add(this.pictureBoxHome);
            this.Controls.Add(this.labelIndice);
            this.Controls.Add(this.textAltura);
            this.Controls.Add(this.labelIngrAltura);
            this.Controls.Add(this.textPeso);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelIMC);
            this.Name = "FormIMC";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormIMC";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHome)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelIMC;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textPeso;
        private System.Windows.Forms.Label labelIngrAltura;
        private System.Windows.Forms.TextBox textAltura;
        private System.Windows.Forms.Label labelIndice;
        private System.Windows.Forms.PictureBox pictureBoxHome;
        private System.Windows.Forms.Button Calcular;
        private System.Windows.Forms.TextBox textIMC;
    }
}