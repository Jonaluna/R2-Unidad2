﻿namespace WindowsFormsApplication1.vista
{
    partial class FormGanancias
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormGanancias));
            this.labelGananciaA = new System.Windows.Forms.Label();
            this.labelIngresar = new System.Windows.Forms.Label();
            this.textPrecioProv = new System.Windows.Forms.TextBox();
            this.labelGanancia = new System.Windows.Forms.Label();
            this.labelPrecio = new System.Windows.Forms.Label();
            this.pictureBoxHome = new System.Windows.Forms.PictureBox();
            this.Arreglos = new System.Windows.Forms.Button();
            this.textGanancia = new System.Windows.Forms.TextBox();
            this.textPrecioPubl = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHome)).BeginInit();
            this.SuspendLayout();
            // 
            // labelGananciaA
            // 
            this.labelGananciaA.AutoSize = true;
            this.labelGananciaA.Font = new System.Drawing.Font("Microsoft Sans Serif", 17.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelGananciaA.Location = new System.Drawing.Point(62, -2);
            this.labelGananciaA.Name = "labelGananciaA";
            this.labelGananciaA.Size = new System.Drawing.Size(232, 29);
            this.labelGananciaA.TabIndex = 0;
            this.labelGananciaA.Text = "Ganancia de artículo";
            // 
            // labelIngresar
            // 
            this.labelIngresar.AutoSize = true;
            this.labelIngresar.Location = new System.Drawing.Point(13, 74);
            this.labelIngresar.Name = "labelIngresar";
            this.labelIngresar.Size = new System.Drawing.Size(153, 13);
            this.labelIngresar.TabIndex = 1;
            this.labelIngresar.Text = "Ingrese el precio del proveedor";
            // 
            // textPrecioProv
            // 
            this.textPrecioProv.Location = new System.Drawing.Point(194, 71);
            this.textPrecioProv.Name = "textPrecioProv";
            this.textPrecioProv.Size = new System.Drawing.Size(100, 20);
            this.textPrecioProv.TabIndex = 2;
            // 
            // labelGanancia
            // 
            this.labelGanancia.AutoSize = true;
            this.labelGanancia.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelGanancia.Location = new System.Drawing.Point(13, 145);
            this.labelGanancia.Name = "labelGanancia";
            this.labelGanancia.Size = new System.Drawing.Size(83, 13);
            this.labelGanancia.TabIndex = 3;
            this.labelGanancia.Text = "La ganancia es:";
            // 
            // labelPrecio
            // 
            this.labelPrecio.AutoSize = true;
            this.labelPrecio.Location = new System.Drawing.Point(12, 197);
            this.labelPrecio.Name = "labelPrecio";
            this.labelPrecio.Size = new System.Drawing.Size(102, 13);
            this.labelPrecio.TabIndex = 5;
            this.labelPrecio.Text = "El precio público es:";
            // 
            // pictureBoxHome
            // 
            this.pictureBoxHome.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHome.Image")));
            this.pictureBoxHome.Location = new System.Drawing.Point(270, 275);
            this.pictureBoxHome.Name = "pictureBoxHome";
            this.pictureBoxHome.Size = new System.Drawing.Size(64, 59);
            this.pictureBoxHome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxHome.TabIndex = 7;
            this.pictureBoxHome.TabStop = false;
            this.pictureBoxHome.Click += new System.EventHandler(this.pictureBoxHome_Click);
            // 
            // Arreglos
            // 
            this.Arreglos.BackColor = System.Drawing.Color.MistyRose;
            this.Arreglos.Font = new System.Drawing.Font("Lucida Calligraphy", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Arreglos.Location = new System.Drawing.Point(116, 275);
            this.Arreglos.Name = "Arreglos";
            this.Arreglos.Size = new System.Drawing.Size(94, 26);
            this.Arreglos.TabIndex = 16;
            this.Arreglos.Text = "Calcular";
            this.Arreglos.UseVisualStyleBackColor = false;
            this.Arreglos.Click += new System.EventHandler(this.Arreglos_Click);
            // 
            // textGanancia
            // 
            this.textGanancia.Enabled = false;
            this.textGanancia.Location = new System.Drawing.Point(120, 145);
            this.textGanancia.Name = "textGanancia";
            this.textGanancia.Size = new System.Drawing.Size(100, 20);
            this.textGanancia.TabIndex = 17;
            // 
            // textPrecioPubl
            // 
            this.textPrecioPubl.Enabled = false;
            this.textPrecioPubl.Location = new System.Drawing.Point(120, 197);
            this.textPrecioPubl.Name = "textPrecioPubl";
            this.textPrecioPubl.Size = new System.Drawing.Size(100, 20);
            this.textPrecioPubl.TabIndex = 18;
            // 
            // FormGanancias
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(334, 331);
            this.ControlBox = false;
            this.Controls.Add(this.textPrecioPubl);
            this.Controls.Add(this.textGanancia);
            this.Controls.Add(this.Arreglos);
            this.Controls.Add(this.pictureBoxHome);
            this.Controls.Add(this.labelPrecio);
            this.Controls.Add(this.labelGanancia);
            this.Controls.Add(this.textPrecioProv);
            this.Controls.Add(this.labelIngresar);
            this.Controls.Add(this.labelGananciaA);
            this.Name = "FormGanancias";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormGanancias";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHome)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelGananciaA;
        private System.Windows.Forms.Label labelIngresar;
        private System.Windows.Forms.TextBox textPrecioProv;
        private System.Windows.Forms.Label labelGanancia;
        private System.Windows.Forms.Label labelPrecio;
        private System.Windows.Forms.PictureBox pictureBoxHome;
        private System.Windows.Forms.Button Arreglos;
        private System.Windows.Forms.TextBox textGanancia;
        private System.Windows.Forms.TextBox textPrecioPubl;
    }
}