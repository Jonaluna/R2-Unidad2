﻿namespace WindowsFormsApplication1.vista
{
    partial class FormDivisas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormDivisas));
            this.label1 = new System.Windows.Forms.Label();
            this.labelIngresar = new System.Windows.Forms.Label();
            this.textPesos = new System.Windows.Forms.TextBox();
            this.pictureBoxHome = new System.Windows.Forms.PictureBox();
            this.labelDol = new System.Windows.Forms.Label();
            this.labelEur = new System.Windows.Forms.Label();
            this.Arreglos = new System.Windows.Forms.Button();
            this.textDolares = new System.Windows.Forms.TextBox();
            this.textEuros = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHome)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft New Tai Lue", 15.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(67, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(206, 27);
            this.label1.TabIndex = 0;
            this.label1.Text = "CAMBIO DE DIVISAS";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // labelIngresar
            // 
            this.labelIngresar.AutoSize = true;
            this.labelIngresar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelIngresar.Location = new System.Drawing.Point(12, 77);
            this.labelIngresar.Name = "labelIngresar";
            this.labelIngresar.Size = new System.Drawing.Size(155, 16);
            this.labelIngresar.TabIndex = 1;
            this.labelIngresar.Text = "Ingresa el total de pesos";
            // 
            // textPesos
            // 
            this.textPesos.Location = new System.Drawing.Point(173, 77);
            this.textPesos.Name = "textPesos";
            this.textPesos.Size = new System.Drawing.Size(100, 23);
            this.textPesos.TabIndex = 2;
            // 
            // pictureBoxHome
            // 
            this.pictureBoxHome.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHome.Image")));
            this.pictureBoxHome.Location = new System.Drawing.Point(271, 272);
            this.pictureBoxHome.Name = "pictureBoxHome";
            this.pictureBoxHome.Size = new System.Drawing.Size(63, 58);
            this.pictureBoxHome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxHome.TabIndex = 5;
            this.pictureBoxHome.TabStop = false;
            this.pictureBoxHome.Click += new System.EventHandler(this.pictureBoxHome_Click);
            // 
            // labelDol
            // 
            this.labelDol.AutoSize = true;
            this.labelDol.Location = new System.Drawing.Point(15, 131);
            this.labelDol.Name = "labelDol";
            this.labelDol.Size = new System.Drawing.Size(248, 17);
            this.labelDol.TabIndex = 6;
            this.labelDol.Text = "La mitad de tu dinero en dólares son: ";
            this.labelDol.Click += new System.EventHandler(this.label2_Click);
            // 
            // labelEur
            // 
            this.labelEur.AutoSize = true;
            this.labelEur.Location = new System.Drawing.Point(15, 198);
            this.labelEur.Name = "labelEur";
            this.labelEur.Size = new System.Drawing.Size(233, 17);
            this.labelEur.TabIndex = 8;
            this.labelEur.Text = "La mitad de tu dinero en euros son:";
            // 
            // Arreglos
            // 
            this.Arreglos.BackColor = System.Drawing.Color.MistyRose;
            this.Arreglos.Font = new System.Drawing.Font("Lucida Calligraphy", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Arreglos.Location = new System.Drawing.Point(116, 293);
            this.Arreglos.Name = "Arreglos";
            this.Arreglos.Size = new System.Drawing.Size(94, 26);
            this.Arreglos.TabIndex = 9;
            this.Arreglos.Text = "Calcular";
            this.Arreglos.UseVisualStyleBackColor = false;
            this.Arreglos.Click += new System.EventHandler(this.Arreglos_Click);
            // 
            // textDolares
            // 
            this.textDolares.Enabled = false;
            this.textDolares.Location = new System.Drawing.Point(110, 160);
            this.textDolares.Name = "textDolares";
            this.textDolares.Size = new System.Drawing.Size(100, 23);
            this.textDolares.TabIndex = 10;
            // 
            // textEuros
            // 
            this.textEuros.Enabled = false;
            this.textEuros.Location = new System.Drawing.Point(110, 232);
            this.textEuros.Name = "textEuros";
            this.textEuros.Size = new System.Drawing.Size(100, 23);
            this.textEuros.TabIndex = 11;
            this.textEuros.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // FormDivisas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(334, 331);
            this.ControlBox = false;
            this.Controls.Add(this.textEuros);
            this.Controls.Add(this.textDolares);
            this.Controls.Add(this.Arreglos);
            this.Controls.Add(this.labelEur);
            this.Controls.Add(this.labelDol);
            this.Controls.Add(this.pictureBoxHome);
            this.Controls.Add(this.textPesos);
            this.Controls.Add(this.labelIngresar);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormDivisas";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormDivisas";
            this.Load += new System.EventHandler(this.FormDivisas_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHome)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelIngresar;
        private System.Windows.Forms.TextBox textPesos;
        private System.Windows.Forms.PictureBox pictureBoxHome;
        private System.Windows.Forms.Label labelDol;
        private System.Windows.Forms.Label labelEur;
        private System.Windows.Forms.Button Arreglos;
        private System.Windows.Forms.TextBox textDolares;
        private System.Windows.Forms.TextBox textEuros;
    }
}