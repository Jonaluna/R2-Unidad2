﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WindowsFormsApplication1;
namespace WindowsFormsApplication1.vista
{
    public partial class FormaMenu : Form
    {
        public FormaMenu()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Program.formaSecuenciales.Show();
            Hide();
        }

        private void Ciclos_Click(object sender, EventArgs e)
        {
            Program.formaCiclos.Show();
            Hide();
        }

        private void Condicionales_Click(object sender, EventArgs e)
        {
            Program.formaCondicionales.Show();
            Hide();
        }

        private void Funciones_Click(object sender, EventArgs e)
        {
            Program.formaFunciones.Show();
            Hide();
        }

        private void Arreglos_Click(object sender, EventArgs e)
        {
            Program.formaArreglos.Show();
            Hide();
        }
    }
}
