﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1.vista.Ciclos
{
    public partial class FormEstudiantesCarrera : Form
    {
        
        public FormEstudiantesCarrera()
        {
            InitializeComponent();
        }

        private void buttonMostrar_Click(object sender, EventArgs e)
        {
            textResultados.Text = "";
            string nombre2;
            int contador = 1;
            int carrera;
            StreamReader file2 = new StreamReader("h:\\calificaciones.txt");

            
            carrera = Int16.Parse(textNumCarr.Text);


            switch (carrera)
            {
                case 1:
                    while ((nombre2 = file2.ReadLine()) != null)
                    {
                        var name = nombre2.Split(';');
                        string nombres = name[1];
                        string apellidos = name[2];
                        string carrera1 = name[4];
                        String letra = carrera1.Substring(0, 1);

                        if (letra.Equals("P"))
                        {

                            textResultados.Text+= contador + " " + nombres + " " + apellidos + " " + carrera1+"\r\n";
                            contador++;
                        }
                    }
                   
                    file2.Close();
                    break;
                case 2:
                    while ((nombre2 = file2.ReadLine()) != null)
                    {
                        var name = nombre2.Split(';');
                        string nombres = name[1];
                        string apellidos = name[2];
                        string carrera1 = name[4];
                        String letra = carrera1.Substring(0, 1);

                        if (letra.Equals("S"))
                        {

                            textResultados.Text += contador + " " + nombres + " " + apellidos + " " + carrera1 + "\r\n";
                            contador++;
                        }
                    }
                    
                    file2.Close();
                    break;
                case 3:
                    while ((nombre2 = file2.ReadLine()) != null)
                    {
                        var names = nombre2.Split(';');
                        string nombres = names[1];
                        string apellidos = names[2];
                        string carrera1 = names[4];
                        String letra = carrera1.Substring(0, 1);

                        if (letra.Equals("E"))
                        {
                            textResultados.Text += contador + " " + nombres + " " + apellidos + " " + carrera1 + "\r\n";
                            contador++;
                        }
                    }
                    
                    file2.Close();
                    break;
                case 4:
                    while ((nombre2 = file2.ReadLine()) != null)
                    {
                        var name = nombre2.Split(';');
                        string nombres = name[1];
                        string apellidos = name[2];
                        string carrera1 = name[4];
                        String letra = carrera1.Substring(0, 1);

                        if (letra.Equals("M"))
                        {

                            textResultados.Text += contador + " " + nombres + " " + apellidos + " " + carrera1 + "\r\n";
                            contador++;
                        }
                    }
                    
                    file2.Close();
                    break;
                case 5:
                    while ((nombre2 = file2.ReadLine()) != null)
                    {
                        var names = nombre2.Split(';');
                        string nombres = names[1];
                        string apellidos = names[2];
                        string carrera1 = names[4];
                        String letra = carrera1.Substring(0, 1);

                        if (letra.Equals("C"))
                        {

                            textResultados.Text += contador + " " + nombres + " " + apellidos + " " + carrera1 + "\r\n";
                            contador++;
                        }
                    }
                   
                    file2.Close();
                    break;
            }
        }

        private void textResultados_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Program.formaListaEstud.Show();
            Hide();
        }
    }
}
