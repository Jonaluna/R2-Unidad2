﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1.vista.Ciclos
{
    public partial class FormNomEstudiantes : Form
    {
        public FormNomEstudiantes()
        {
            InitializeComponent();
        }

        private void buttonMostrar_Click(object sender, EventArgs e)
        {
            string linea;

            textResultado.Text = "";
            StreamReader file = new StreamReader("h:\\calificaciones.txt");
            while ((linea = file.ReadLine()) != null)
            {
                var names = linea.Split(';');
               
                string firstName = names[1];
                string lastName = names[2];
                
                textResultado.Text +=  firstName + " " + lastName +"\r\n";

            }

            file.Close();

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Program.formaListaEstud.Show();
            Hide();
        }
    }
}
