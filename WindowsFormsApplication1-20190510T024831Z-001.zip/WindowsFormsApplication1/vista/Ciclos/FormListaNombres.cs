﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1.vista
{
    public partial class FormListaNombres : Form
    {
        public FormListaNombres()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string elemento = comboBox1.GetItemText(comboBox1.SelectedItem);
           
            switch (elemento)
            {
                case "Lista Nombres":

                    string nombre;
                    textResultados.Text = "";

                    StreamReader file = new StreamReader("h:\\nombres.txt");
                    while ((nombre = file.ReadLine()) != null)
                    {
                        textResultados.Text+= nombre+"\r\n";
                    }
                    
                    file.Close();
                    break;
                case "Lista de nombres con numeración":
                    textResultados.Text = "";
                    string nombre2;
                    int contador = 1;


                    StreamReader file2 = new StreamReader("h:\\nombres.txt");
                    while ((nombre2 = file2.ReadLine()) != null)
                    {
                        textResultados.Text += contador + " " + nombre2+"\r\n";
                        contador++;
                    }
                   
                    file2.Close();
                    break;
                case "Lista de nombres en Mayúsculas":
                    textResultados.Text = "";
                    string nombre3;
                    int contador1 = 1;
                    StreamReader file3 = new StreamReader("h:\\nombres.txt");
                    while ((nombre3 = file3.ReadLine()) != null)
                    {
                        textResultados.Text += contador1 + " " + nombre3.ToUpper()+"\r\n";
                        contador1++;
                    }
                    
                    file3.Close();
                    break;
                case "Lista nombres con mayúsculas el nombre":
                    textResultados.Text = "";
                    string nombre4;
                    int contador2 = 1;


                    StreamReader file4 = new StreamReader("h:\\nombres1.txt");
                    while ((nombre4 = file4.ReadLine()) != null)
                    {
                        var names = nombre4.Split('*');
                        string nombres = names[0];
                        string apellidos = names[1];
                        textResultados.Text += contador2 + " " + nombres.ToUpper() + apellidos+"\r\n";
                        contador2++;
                    }
                    
                    file4.Close();
                    break;
                case "Lista nombres empezando con apellido en mayúsculas":
                    textResultados.Text = "";
                    string nombre5;
                    int contador3 = 1;


                    StreamReader file5 = new StreamReader("h:\\nombres1.txt");
                    while ((nombre5 = file5.ReadLine()) != null)
                    {
                        var names = nombre5.Split('*');
                        string nombres = names[0];
                        string apellidos = names[1];
                        textResultados.Text += contador3 + " " + apellidos.ToUpper() + " " + nombres+"\r\n";
                        contador3++;
                    }
                    
                    file5.Close();
                    break;

                default:
                    
                    break;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Program.formaCiclos.Show();
            Hide();
        }
    }
}
