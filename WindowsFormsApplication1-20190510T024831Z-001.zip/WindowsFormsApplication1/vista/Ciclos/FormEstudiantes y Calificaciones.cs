﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1.vista.Ciclos
{
    public partial class FormEstudiantes_y_Calificaciones : Form
    {
        public FormEstudiantes_y_Calificaciones()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void buttonMostrar_Click(object sender, EventArgs e)
        {
            textResultado.Text = "";
            string nombre4;



            StreamReader file4 = new StreamReader("h:\\calificaciones.txt");
            while ((nombre4 = file4.ReadLine()) != null)
            {
                var names = nombre4.Split(';');
                string numero = names[0];
                string nombres = names[1];
                string apellidos = names[2];
                string calificacion1 = names[5];
                string calificacion2 = names[6];
                string calificacion3 = names[7];
                string calificacion4 = names[8];
                textResultado.Text+= numero + " " + nombres + " " + apellidos + "  C1" + calificacion1 + "  C2" + calificacion2 + "  C3" + calificacion3 + "  C4" + calificacion4+"\r\n";
            }
        
            file4.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Program.formaListaEstud.Show();
            Hide();
        }
    }
}
