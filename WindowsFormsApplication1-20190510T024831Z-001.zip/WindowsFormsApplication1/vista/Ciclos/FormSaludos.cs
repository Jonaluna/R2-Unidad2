﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1.vista
{
    public partial class FormSaludos : Form
    {
        public FormSaludos()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string elemento = comboBox1.GetItemText(comboBox1.SelectedItem);

            switch (elemento)
            {
                case "Saludame 10 veces":
                    {
                        Program.formaSaludo10.Show();
                        Hide();
                        break;
                    }
                case "¿Quieres que te salude?":
                    {
                        Program.formaSaludoSI.Show();
                        Hide();
                        break;
                    }
            }
            }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Program.formaCiclos.Show();
            Hide();
        }
    }
}
