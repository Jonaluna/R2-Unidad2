﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1.vista
{
    public partial class FormCiclos : Form
    {
        public FormCiclos()
        {
            InitializeComponent();
        }

        private void buttonNombres_Click(object sender, EventArgs e)
        {
            Program.formaListaNombres.Show();
            Hide();
        }

        private void buttonSaludo_Click(object sender, EventArgs e)
        {
            Program.formaSaludos.Show();
            Hide();
        }

        private void buttonEstudiante_Click(object sender, EventArgs e)
        {
            Program.formaListaEstud.Show();
            Hide();
        }

        private void pictureHome_Click(object sender, EventArgs e)
        {
            Program.formaMenu.Show();
            Hide();
        }
    }
}
