﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1.vista
{
    public partial class FormSaludo10 : Form
    {
        public FormSaludo10()
        {
            InitializeComponent();
        }

        private void pictureBoxBack_Click(object sender, EventArgs e)
        {
            Program.formaSaludos.Show();
            Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textResultado.Text = "";
            string nombre;

            
            nombre = textNombre.Text;
            string ruta = "h:\\Ciclos1_[" + nombre + "].txt";
            StreamWriter file = new StreamWriter(ruta, true);
            file.WriteLine(nombre);
            for (int contador = 1; contador <= 10; contador++)
            {
               textResultado.Text+= contador + " Hola " + nombre + " que tengas un lindo día"+"\r\n";
            }
            textRuta.Text = ruta;
            file.Close();
        }
    }
}
