﻿namespace WindowsFormsApplication1.vista
{
    partial class FormCiclos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormCiclos));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.labelCiclos = new System.Windows.Forms.Label();
            this.buttonSaludo = new System.Windows.Forms.Button();
            this.buttonNombres = new System.Windows.Forms.Button();
            this.buttonEstudiante = new System.Windows.Forms.Button();
            this.pictureHome = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureHome)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-24, -2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(400, 395);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // labelCiclos
            // 
            this.labelCiclos.AutoSize = true;
            this.labelCiclos.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.labelCiclos.Font = new System.Drawing.Font("Lucida Calligraphy", 17.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCiclos.Location = new System.Drawing.Point(132, 35);
            this.labelCiclos.Name = "labelCiclos";
            this.labelCiclos.Size = new System.Drawing.Size(101, 29);
            this.labelCiclos.TabIndex = 1;
            this.labelCiclos.Text = "CICLOS";
            // 
            // buttonSaludo
            // 
            this.buttonSaludo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.buttonSaludo.Font = new System.Drawing.Font("Mongolian Baiti", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSaludo.Location = new System.Drawing.Point(47, 123);
            this.buttonSaludo.Name = "buttonSaludo";
            this.buttonSaludo.Size = new System.Drawing.Size(85, 33);
            this.buttonSaludo.TabIndex = 2;
            this.buttonSaludo.Text = "SALUDOS";
            this.buttonSaludo.UseVisualStyleBackColor = false;
            this.buttonSaludo.Click += new System.EventHandler(this.buttonSaludo_Click);
            // 
            // buttonNombres
            // 
            this.buttonNombres.BackColor = System.Drawing.Color.PeachPuff;
            this.buttonNombres.Font = new System.Drawing.Font("Mongolian Baiti", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonNombres.Location = new System.Drawing.Point(137, 189);
            this.buttonNombres.Name = "buttonNombres";
            this.buttonNombres.Size = new System.Drawing.Size(96, 34);
            this.buttonNombres.TabIndex = 3;
            this.buttonNombres.Text = "LISTA DE NOMBRES";
            this.buttonNombres.UseVisualStyleBackColor = false;
            this.buttonNombres.Click += new System.EventHandler(this.buttonNombres_Click);
            // 
            // buttonEstudiante
            // 
            this.buttonEstudiante.BackColor = System.Drawing.Color.PeachPuff;
            this.buttonEstudiante.Font = new System.Drawing.Font("Mongolian Baiti", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonEstudiante.Location = new System.Drawing.Point(238, 244);
            this.buttonEstudiante.Name = "buttonEstudiante";
            this.buttonEstudiante.Size = new System.Drawing.Size(95, 41);
            this.buttonEstudiante.TabIndex = 4;
            this.buttonEstudiante.Text = "LISTA DE ESTUDIANTES";
            this.buttonEstudiante.UseVisualStyleBackColor = false;
            this.buttonEstudiante.Click += new System.EventHandler(this.buttonEstudiante_Click);
            // 
            // pictureHome
            // 
            this.pictureHome.Image = ((System.Drawing.Image)(resources.GetObject("pictureHome.Image")));
            this.pictureHome.Location = new System.Drawing.Point(314, 345);
            this.pictureHome.Name = "pictureHome";
            this.pictureHome.Size = new System.Drawing.Size(62, 48);
            this.pictureHome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureHome.TabIndex = 5;
            this.pictureHome.TabStop = false;
            this.pictureHome.Click += new System.EventHandler(this.pictureHome_Click);
            // 
            // FormCiclos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(371, 393);
            this.ControlBox = false;
            this.Controls.Add(this.pictureHome);
            this.Controls.Add(this.buttonEstudiante);
            this.Controls.Add(this.buttonNombres);
            this.Controls.Add(this.buttonSaludo);
            this.Controls.Add(this.labelCiclos);
            this.Controls.Add(this.pictureBox1);
            this.Name = "FormCiclos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormCiclos";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureHome)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label labelCiclos;
        private System.Windows.Forms.Button buttonSaludo;
        private System.Windows.Forms.Button buttonNombres;
        private System.Windows.Forms.Button buttonEstudiante;
        private System.Windows.Forms.PictureBox pictureHome;
    }
}