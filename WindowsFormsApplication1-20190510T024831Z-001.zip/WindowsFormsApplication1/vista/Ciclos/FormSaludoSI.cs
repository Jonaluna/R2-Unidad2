﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1.vista
{
    public partial class FormSaludoSI : Form
    {
        public FormSaludoSI()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Program.formaSaludos.Show();
            Hide();
        }

        private void buttonMostrar_Click(object sender, EventArgs e)
        {
            textResultado.Text = "";
            string nombre2;
            nombre2 = textNombre.Text;
            
            

                StreamWriter file2 = new StreamWriter("h:\\Ciclos2_[nombre].txt", true);
                file2.WriteLine(nombre2);
                
               textResultado.Text=" Hola " + nombre2 + " que tengas un lindo día";
              

                file2.Close();
            
        }
    }
}
