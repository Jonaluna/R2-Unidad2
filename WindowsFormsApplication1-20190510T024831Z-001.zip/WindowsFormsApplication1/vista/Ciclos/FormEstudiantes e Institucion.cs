﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1.vista.Ciclos
{

    public partial class FormEstudiantes_e_Institucion : Form
    {
        
        public FormEstudiantes_e_Institucion()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Program.formaListaEstud.Show();
            Hide();
        }

        private void buttonMostrar_Click(object sender, EventArgs e)
        {
            textResultados.Text = "";
            string nombre3;
            int contador1 = 1, institucion;
            StreamReader file3 = new StreamReader("h:\\calificaciones.txt");

           
            institucion = Int16.Parse(textNuIns.Text);

            switch (institucion)
            {
                case 1:
                    while ((nombre3 = file3.ReadLine()) != null)
                    {
                        var names = nombre3.Split(';');
                        string nombres = names[1];
                        string apellidos = names[2];
                        string institu = names[3];
                        String caracter = institu.Substring(0, 1);

                        if (caracter.Equals("C"))
                        {

                            textResultados.Text+= contador1 + " " + nombres + " " + apellidos + " " + institu+"\r\n";
                            contador1++;
                        }
                    }
                   
                    file3.Close();
                    break;
                case 2:
                    while ((nombre3 = file3.ReadLine()) != null)
                    {
                        var names = nombre3.Split(';');
                        string nombres = names[1];
                        string apellidos = names[2];
                        string institu = names[3];
                        String caracter = institu.Substring(0, 1);

                        if (caracter.Equals("R"))
                        {

                            textResultados.Text += contador1 + " " + nombres + " " + apellidos + " " + institu + "\r\n";
                            contador1++;
                        }
                    }
                   
                    file3.Close();
                    break;
            }
        }
    }
}
