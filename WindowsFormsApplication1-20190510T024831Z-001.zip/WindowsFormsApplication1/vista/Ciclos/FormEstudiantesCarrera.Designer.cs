﻿namespace WindowsFormsApplication1.vista.Ciclos
{
    partial class FormEstudiantesCarrera
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormEstudiantesCarrera));
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.textResultados = new System.Windows.Forms.TextBox();
            this.buttonMostrar = new System.Windows.Forms.Button();
            this.labelIngNum = new System.Windows.Forms.Label();
            this.textNumCarr = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(89, -1);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(271, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "Estudiantes y carrera";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(389, 619);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(55, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // textResultados
            // 
            this.textResultados.Enabled = false;
            this.textResultados.Location = new System.Drawing.Point(35, 104);
            this.textResultados.Multiline = true;
            this.textResultados.Name = "textResultados";
            this.textResultados.Size = new System.Drawing.Size(373, 510);
            this.textResultados.TabIndex = 2;
            this.textResultados.TextChanged += new System.EventHandler(this.textResultados_TextChanged);
            // 
            // buttonMostrar
            // 
            this.buttonMostrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMostrar.Location = new System.Drawing.Point(170, 619);
            this.buttonMostrar.Name = "buttonMostrar";
            this.buttonMostrar.Size = new System.Drawing.Size(92, 41);
            this.buttonMostrar.TabIndex = 3;
            this.buttonMostrar.Text = "Mostrar";
            this.buttonMostrar.UseVisualStyleBackColor = true;
            this.buttonMostrar.Click += new System.EventHandler(this.buttonMostrar_Click);
            // 
            // labelIngNum
            // 
            this.labelIngNum.AutoSize = true;
            this.labelIngNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelIngNum.Location = new System.Drawing.Point(114, 62);
            this.labelIngNum.Name = "labelIngNum";
            this.labelIngNum.Size = new System.Drawing.Size(188, 16);
            this.labelIngNum.TabIndex = 7;
            this.labelIngNum.Text = "Ingrese un número de Carrera:";
            // 
            // textNumCarr
            // 
            this.textNumCarr.Location = new System.Drawing.Point(152, 81);
            this.textNumCarr.Name = "textNumCarr";
            this.textNumCarr.Size = new System.Drawing.Size(110, 20);
            this.textNumCarr.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(17, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(390, 16);
            this.label2.TabIndex = 8;
            this.label2.Text = "1.Soporte Técnico.   3.Electricidad.   4.Mecánica.  5.Contabilidad.";
            // 
            // FormEstudiantesCarrera
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.ClientSize = new System.Drawing.Size(447, 672);
            this.ControlBox = false;
            this.Controls.Add(this.label2);
            this.Controls.Add(this.labelIngNum);
            this.Controls.Add(this.textNumCarr);
            this.Controls.Add(this.buttonMostrar);
            this.Controls.Add(this.textResultados);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Name = "FormEstudiantesCarrera";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormEstudiantesCarrera";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox textResultados;
        private System.Windows.Forms.Button buttonMostrar;
        private System.Windows.Forms.Label labelIngNum;
        private System.Windows.Forms.TextBox textNumCarr;
        private System.Windows.Forms.Label label2;
    }
}