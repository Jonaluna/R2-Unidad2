﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1.vista
{
    public partial class FormListaEstudiantes : Form
    {
        public FormListaEstudiantes()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string elemento = comboBox1.GetItemText(comboBox1.SelectedItem);
            switch (elemento)
            {
                case "Listar todos los nombres de estudiantes sin ninguna condición":
                    {
                        Program.formaNomEstudi.Show();
                        Hide();
                        break;
                    }
                case "Listar todos los nombres de estudiantes que son de una carrera en específico":
                    {
                        Program.formaEstudCarre.Show();
                        Hide();
                        break;
                    }

                case "Listar todos los nombres de estudiantes que son de una institución en específico":
                    {
                        Program.formaEstudeInstitu.Show();
                        Hide();
                        break;
                    }
                case "Listar los nombres de estudiantes y sus calificaciones":
                    {
                        Program.formaEstudyClaif.Show();
                        Hide();
                        break;
                    }

           



            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Program.formaCiclos.Show();
            Hide();
        }
    }
}
