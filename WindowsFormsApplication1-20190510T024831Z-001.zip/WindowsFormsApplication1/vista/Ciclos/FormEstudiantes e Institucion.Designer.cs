﻿namespace WindowsFormsApplication1.vista.Ciclos
{
    partial class FormEstudiantes_e_Institucion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormEstudiantes_e_Institucion));
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.textResultados = new System.Windows.Forms.TextBox();
            this.buttonMostrar = new System.Windows.Forms.Button();
            this.textNuIns = new System.Windows.Forms.TextBox();
            this.labelIngNum = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(54, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(343, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "Estudiantes y su institución";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(392, 596);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(53, 45);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // textResultados
            // 
            this.textResultados.AcceptsReturn = true;
            this.textResultados.Enabled = false;
            this.textResultados.Location = new System.Drawing.Point(24, 90);
            this.textResultados.Multiline = true;
            this.textResultados.Name = "textResultados";
            this.textResultados.Size = new System.Drawing.Size(398, 500);
            this.textResultados.TabIndex = 2;
            // 
            // buttonMostrar
            // 
            this.buttonMostrar.Font = new System.Drawing.Font("Century Gothic", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMostrar.Location = new System.Drawing.Point(162, 598);
            this.buttonMostrar.Name = "buttonMostrar";
            this.buttonMostrar.Size = new System.Drawing.Size(101, 33);
            this.buttonMostrar.TabIndex = 3;
            this.buttonMostrar.Text = "Mostrar";
            this.buttonMostrar.UseVisualStyleBackColor = true;
            this.buttonMostrar.Click += new System.EventHandler(this.buttonMostrar_Click);
            // 
            // textNuIns
            // 
            this.textNuIns.Location = new System.Drawing.Point(162, 64);
            this.textNuIns.Name = "textNuIns";
            this.textNuIns.Size = new System.Drawing.Size(110, 20);
            this.textNuIns.TabIndex = 4;
            // 
            // labelIngNum
            // 
            this.labelIngNum.AutoSize = true;
            this.labelIngNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelIngNum.Location = new System.Drawing.Point(57, 45);
            this.labelIngNum.Name = "labelIngNum";
            this.labelIngNum.Size = new System.Drawing.Size(354, 16);
            this.labelIngNum.TabIndex = 5;
            this.labelIngNum.Text = "Ingrese un número de institución 1.CBTis 75. 2.Rébsamen.:";
            // 
            // FormEstudiantes_e_Institucion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(447, 643);
            this.ControlBox = false;
            this.Controls.Add(this.labelIngNum);
            this.Controls.Add(this.textNuIns);
            this.Controls.Add(this.buttonMostrar);
            this.Controls.Add(this.textResultados);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Name = "FormEstudiantes_e_Institucion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormEstudiantes_e_Institucion";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox textResultados;
        private System.Windows.Forms.Button buttonMostrar;
        private System.Windows.Forms.TextBox textNuIns;
        private System.Windows.Forms.Label labelIngNum;
    }
}