﻿namespace WindowsFormsApplication1.vista
{
    partial class FormArreglos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormArreglos));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.labelArreglos = new System.Windows.Forms.Label();
            this.buttonAritmetica = new System.Windows.Forms.Button();
            this.buttonNumM = new System.Windows.Forms.Button();
            this.buttonPalabras = new System.Windows.Forms.Button();
            this.buttonNombres = new System.Windows.Forms.Button();
            this.pictureHome = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureHome)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-4, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(314, 337);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // labelArreglos
            // 
            this.labelArreglos.AutoSize = true;
            this.labelArreglos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelArreglos.Font = new System.Drawing.Font("Lucida Handwriting", 16.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelArreglos.Location = new System.Drawing.Point(85, 18);
            this.labelArreglos.Name = "labelArreglos";
            this.labelArreglos.Size = new System.Drawing.Size(139, 28);
            this.labelArreglos.TabIndex = 1;
            this.labelArreglos.Text = "ARREGLOS";
            // 
            // buttonAritmetica
            // 
            this.buttonAritmetica.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAritmetica.Location = new System.Drawing.Point(30, 90);
            this.buttonAritmetica.Name = "buttonAritmetica";
            this.buttonAritmetica.Size = new System.Drawing.Size(91, 45);
            this.buttonAritmetica.TabIndex = 2;
            this.buttonAritmetica.Text = "MEDIA ARITMÉTICA";
            this.buttonAritmetica.UseVisualStyleBackColor = true;
            this.buttonAritmetica.Click += new System.EventHandler(this.buttonAritmetica_Click);
            // 
            // buttonNumM
            // 
            this.buttonNumM.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonNumM.Location = new System.Drawing.Point(30, 166);
            this.buttonNumM.Name = "buttonNumM";
            this.buttonNumM.Size = new System.Drawing.Size(91, 44);
            this.buttonNumM.TabIndex = 3;
            this.buttonNumM.Text = "NÚMERO MAYOR Y MENOR";
            this.buttonNumM.UseVisualStyleBackColor = true;
            this.buttonNumM.Click += new System.EventHandler(this.buttonNumM_Click);
            // 
            // buttonPalabras
            // 
            this.buttonPalabras.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPalabras.Location = new System.Drawing.Point(192, 90);
            this.buttonPalabras.Name = "buttonPalabras";
            this.buttonPalabras.Size = new System.Drawing.Size(88, 45);
            this.buttonPalabras.TabIndex = 4;
            this.buttonPalabras.Text = "CONTAR PALABRAS";
            this.buttonPalabras.UseVisualStyleBackColor = true;
            this.buttonPalabras.Click += new System.EventHandler(this.buttonPalabras_Click);
            // 
            // buttonNombres
            // 
            this.buttonNombres.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonNombres.Location = new System.Drawing.Point(192, 166);
            this.buttonNombres.Name = "buttonNombres";
            this.buttonNombres.Size = new System.Drawing.Size(88, 44);
            this.buttonNombres.TabIndex = 5;
            this.buttonNombres.Text = "NOMBRES";
            this.buttonNombres.UseVisualStyleBackColor = true;
            this.buttonNombres.Click += new System.EventHandler(this.buttonNombres_Click);
            // 
            // pictureHome
            // 
            this.pictureHome.Image = ((System.Drawing.Image)(resources.GetObject("pictureHome.Image")));
            this.pictureHome.Location = new System.Drawing.Point(257, 288);
            this.pictureHome.Name = "pictureHome";
            this.pictureHome.Size = new System.Drawing.Size(53, 49);
            this.pictureHome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureHome.TabIndex = 6;
            this.pictureHome.TabStop = false;
            this.pictureHome.Click += new System.EventHandler(this.pictureHome_Click);
            // 
            // FormArreglos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(308, 337);
            this.Controls.Add(this.pictureHome);
            this.Controls.Add(this.buttonNombres);
            this.Controls.Add(this.buttonPalabras);
            this.Controls.Add(this.buttonNumM);
            this.Controls.Add(this.buttonAritmetica);
            this.Controls.Add(this.labelArreglos);
            this.Controls.Add(this.pictureBox1);
            this.Name = "FormArreglos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormArreglos";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureHome)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label labelArreglos;
        private System.Windows.Forms.Button buttonAritmetica;
        private System.Windows.Forms.Button buttonNumM;
        private System.Windows.Forms.Button buttonPalabras;
        private System.Windows.Forms.Button buttonNombres;
        private System.Windows.Forms.PictureBox pictureHome;
    }
}