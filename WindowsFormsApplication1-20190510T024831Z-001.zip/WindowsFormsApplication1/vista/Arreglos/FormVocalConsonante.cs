﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1.vista
{
    public partial class FormVocalConsonante : Form
    {
        public FormVocalConsonante()
        {
            InitializeComponent();
        }

        private void Calcular_Click(object sender, EventArgs e)
        {
            int s = 0, i;
            string letra;
            string texto = textTexto.Text;
            int tamaño = texto.Length, cVoc = 0, cCon = 0, cPal = 1;
            string[] arreglo = new string[tamaño];

            for (i = 0; i < tamaño; i++)
            {
                s++;
                letra = texto.Substring(i, s);


                arreglo[i] = letra;
                String caracter1 = letra.ToUpper();


                if (caracter1.Equals("A") || caracter1.Equals("E") || caracter1.Equals("I") || caracter1.Equals("O") || caracter1.Equals("U") || caracter1.Equals("Á") || caracter1.Equals("É") || caracter1.Equals("Í") || caracter1.Equals("Ó") || caracter1.Equals("Ú"))
                {
                    cVoc++;
                }
                else if (letra.Equals(" "))
                {
                    cPal++;
                }
                else
                {
                    cCon++;
                }
                s--;
            }
            textPalabras.Text = "" + cPal;
            textVocales.Text = "" + cVoc;
            textConsonantes.Text=""+ cCon;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Program.formaArreglos.Show();
            Hide();
        }
    }
}
