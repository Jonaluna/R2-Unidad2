﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1.vista
{
    public partial class FormArreglos : Form
    {
        public FormArreglos()
        {
            InitializeComponent();
        }

        private void buttonNumM_Click(object sender, EventArgs e)
        {
            Program.formaNumMayMen.Show();
            Hide();

        }

        private void pictureHome_Click(object sender, EventArgs e)
        {
            Program.formaMenu.Show();
            Hide();
        }

        private void buttonAritmetica_Click(object sender, EventArgs e)
        {
            Program.formaMediaAritmetica.Show();
            Hide();
        }

        private void buttonPalabras_Click(object sender, EventArgs e)
        {
            Program.formaVocalCons.Show();
            Hide();
        }

        private void buttonNombres_Click(object sender, EventArgs e)
        {
            Program.formaNombres.Show();
            Hide();
        }
    }
}
