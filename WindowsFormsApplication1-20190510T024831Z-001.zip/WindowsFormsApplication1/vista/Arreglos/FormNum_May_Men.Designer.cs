﻿namespace WindowsFormsApplication1.vista
{
    partial class FormNum_May_Men
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormNum_May_Men));
            this.label1 = new System.Windows.Forms.Label();
            this.labelPos1 = new System.Windows.Forms.Label();
            this.labelNumMay = new System.Windows.Forms.Label();
            this.labelNumMen = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.textMayor = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textMenor = new System.Windows.Forms.TextBox();
            this.Calcular = new System.Windows.Forms.Button();
            this.Agregar = new System.Windows.Forms.Button();
            this.textNumeros = new System.Windows.Forms.TextBox();
            this.labelNombre = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 17.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(46, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(264, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Número mayor y menor";
            // 
            // labelPos1
            // 
            this.labelPos1.AutoSize = true;
            this.labelPos1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPos1.Location = new System.Drawing.Point(14, 139);
            this.labelPos1.Name = "labelPos1";
            this.labelPos1.Size = new System.Drawing.Size(47, 13);
            this.labelPos1.TabIndex = 0;
            this.labelPos1.Text = "Posición";
            // 
            // labelNumMay
            // 
            this.labelNumMay.AutoSize = true;
            this.labelNumMay.Location = new System.Drawing.Point(14, 152);
            this.labelNumMay.Name = "labelNumMay";
            this.labelNumMay.Size = new System.Drawing.Size(76, 13);
            this.labelNumMay.TabIndex = 2;
            this.labelNumMay.Text = "Número Mayor";
            // 
            // labelNumMen
            // 
            this.labelNumMen.AutoSize = true;
            this.labelNumMen.Location = new System.Drawing.Point(176, 152);
            this.labelNumMen.Name = "labelNumMen";
            this.labelNumMen.Size = new System.Drawing.Size(77, 13);
            this.labelNumMen.TabIndex = 4;
            this.labelNumMen.Text = "Número Menor";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(270, 205);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(63, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // textMayor
            // 
            this.textMayor.AcceptsReturn = true;
            this.textMayor.Enabled = false;
            this.textMayor.Location = new System.Drawing.Point(104, 136);
            this.textMayor.Multiline = true;
            this.textMayor.Name = "textMayor";
            this.textMayor.Size = new System.Drawing.Size(51, 40);
            this.textMayor.TabIndex = 33;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(176, 136);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 34;
            this.label2.Text = "Posición";
            // 
            // textMenor
            // 
            this.textMenor.AcceptsReturn = true;
            this.textMenor.Enabled = false;
            this.textMenor.Location = new System.Drawing.Point(266, 133);
            this.textMenor.Multiline = true;
            this.textMenor.Name = "textMenor";
            this.textMenor.Size = new System.Drawing.Size(56, 43);
            this.textMenor.TabIndex = 35;
            // 
            // Calcular
            // 
            this.Calcular.BackColor = System.Drawing.Color.MistyRose;
            this.Calcular.Font = new System.Drawing.Font("Lucida Calligraphy", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Calcular.Location = new System.Drawing.Point(117, 225);
            this.Calcular.Name = "Calcular";
            this.Calcular.Size = new System.Drawing.Size(94, 26);
            this.Calcular.TabIndex = 36;
            this.Calcular.Text = "Verificar";
            this.Calcular.UseVisualStyleBackColor = false;
            this.Calcular.Click += new System.EventHandler(this.Calcular_Click);
            // 
            // Agregar
            // 
            this.Agregar.BackColor = System.Drawing.Color.MistyRose;
            this.Agregar.Font = new System.Drawing.Font("Lucida Calligraphy", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Agregar.Location = new System.Drawing.Point(148, 76);
            this.Agregar.Name = "Agregar";
            this.Agregar.Size = new System.Drawing.Size(141, 26);
            this.Agregar.TabIndex = 39;
            this.Agregar.Text = "Agregar n°1";
            this.Agregar.UseVisualStyleBackColor = false;
            this.Agregar.Click += new System.EventHandler(this.Agregar_Click);
            // 
            // textNumeros
            // 
            this.textNumeros.Location = new System.Drawing.Point(148, 50);
            this.textNumeros.Name = "textNumeros";
            this.textNumeros.Size = new System.Drawing.Size(53, 20);
            this.textNumeros.TabIndex = 38;
            // 
            // labelNombre
            // 
            this.labelNombre.AutoSize = true;
            this.labelNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNombre.Location = new System.Drawing.Point(14, 50);
            this.labelNombre.Name = "labelNombre";
            this.labelNombre.Size = new System.Drawing.Size(128, 16);
            this.labelNombre.TabIndex = 37;
            this.labelNombre.Text = "Ingresa 10 números:";
            // 
            // FormNum_May_Men
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Bisque;
            this.ClientSize = new System.Drawing.Size(334, 263);
            this.ControlBox = false;
            this.Controls.Add(this.Agregar);
            this.Controls.Add(this.textNumeros);
            this.Controls.Add(this.labelNombre);
            this.Controls.Add(this.Calcular);
            this.Controls.Add(this.textMenor);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textMayor);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.labelNumMen);
            this.Controls.Add(this.labelNumMay);
            this.Controls.Add(this.labelPos1);
            this.Controls.Add(this.label1);
            this.Name = "FormNum_May_Men";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormNum_May_Men";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelPos1;
        private System.Windows.Forms.Label labelNumMay;
        private System.Windows.Forms.Label labelNumMen;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox textMayor;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textMenor;
        private System.Windows.Forms.Button Calcular;
        private System.Windows.Forms.Button Agregar;
        private System.Windows.Forms.TextBox textNumeros;
        private System.Windows.Forms.Label labelNombre;
    }
}