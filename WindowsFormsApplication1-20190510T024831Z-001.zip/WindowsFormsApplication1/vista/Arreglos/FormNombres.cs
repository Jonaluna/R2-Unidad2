﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace WindowsFormsApplication1.vista
{
    public partial class FormNombres : Form
    {
       

        public FormNombres()
        {
            InitializeComponent();
        }

        public object Enviroment { get; }

        private void Calcular_Click(object sender, EventArgs e)
        {
             string linea;


             StreamReader file = new StreamReader("h:\\calificaciones.txt");
             while ((linea = file.ReadLine()) != null)
             {
                 var names = linea.Split(';');
                 string num = names[0];
                 string firstName = names[1];
                 string lastName = names[2];
                 string carrera = names[4];
                 textLista.Text +=num + " " + firstName + " " + lastName + "///Carrera: " + carrera+"\r\n";
                 
             }
             
             file.Close();
            

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Program.formaArreglos.Show();
            Hide();
        }
    }
}
