﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1.vista
{
    public partial class FormMediaAritmetica : Form
    {
        int[] numero = new int[10];
        
        int i=0, media, suma = 0;
        public FormMediaAritmetica()
        {
            InitializeComponent();
        }

        private void Agregar_Click(object sender, EventArgs e)
        {
            if (textNumeros.Text.Equals("") || Convert.ToInt16(textNumeros.Text)<=0)
            {
                MessageBox.Show("Debes ingresar Numeros enteros positivos","ERROR",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }else
            {
                numero[i]= Convert.ToInt16(textNumeros.Text);
                
               
                    suma = suma + numero[i];
                i++;
                if (i < 10)
                {
                    textNumeros.Text = "";
                    
                    Agregar.Text = "Agregar n°" + Math.Abs( i+1);
                }
                else{
                    Agregar.Enabled=false;
                    Calcular.Enabled = true;
                }

            }
            

        }

        private void labelNombre_Click(object sender, EventArgs e)
        {

        }

        private void Calcular_Click(object sender, EventArgs e)
        {
        
            media = suma / 10;
            textResultado.Text="La suma de todos los numeros es:"+ suma + "                Y su Media Aritmetica es:" +media;

           
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Program.formaArreglos.Show();
            Hide();
        }
    }
}
