﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1.vista
{
    public partial class FormNum_May_Men : Form
    {
        int[] numero = new int[10];
        int iMa,iMe;

        int i = 0;
        public FormNum_May_Men()
        {
            InitializeComponent();
        }

        private void Agregar_Click(object sender, EventArgs e)
        {
            if (textNumeros.Text.Equals("") || Convert.ToInt16(textNumeros.Text) <= 0)
            {
                MessageBox.Show("Debes ingresar Numeros enteros positivos", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                numero[i] = Convert.ToInt16(textNumeros.Text);


               
                i++;
                if (i < 10)
                {
                    textNumeros.Text = "";

                    Agregar.Text = "Agregar n°" + Math.Abs(i + 1);
                }
                else
                {
                    Agregar.Enabled = false;
                    Calcular.Enabled = true;
                }

            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Program.formaArreglos.Show();
            Hide();
        }

        private void Calcular_Click(object sender, EventArgs e)

        {
            int resultado2 = numero[0];
            for (int i = 0; i < 10; i++)
            {
                if (numero[i] < resultado2)
                {

                    resultado2 = numero[i];
                    iMe = i;
                }

            }
            int resultado1 = numero[0];
            for (int i1 = 0; i1 < 10; i1++)
            {
                if (numero[i1] > resultado1)
                {

                    resultado1 = numero[i1];
                    iMa = i1;

                }

            }
            textMayor.Text = iMa + "\r\n" + resultado1;
            textMenor.Text = iMe + "\r\n" + resultado2;


        }
       
    }
}
