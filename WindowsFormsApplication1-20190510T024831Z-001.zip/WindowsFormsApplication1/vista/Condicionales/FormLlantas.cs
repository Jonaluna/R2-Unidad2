﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1.vista
{
    public partial class FormLlantas : Form
    {
        public FormLlantas()
        {
            InitializeComponent();
        }

        private void FormLlantas_Load(object sender, EventArgs e)
        {

        }

        private void pictureBoxHome_Click(object sender, EventArgs e)
        {
            Program.formaCondicionales.Show();
            Hide();
        }

        private void Calcular_Click(object sender, EventArgs e)
        {
            string nombreUs, ruta = "H:\\Errores_Usuario.txt";
            int cantLlantas, c = 1;
            double montoTotal;
            StreamWriter file = new StreamWriter(ruta);

            
            nombreUs = textNombre.Text;
        
                
                cantLlantas = Int16.Parse(textNLlantas.Text);
               
                if (cantLlantas >= 1 && cantLlantas <= 50)
                {
                    if (cantLlantas < 5)
                    {
                        montoTotal = cantLlantas * 800;
                        textResultado.Text= "$" + montoTotal;
                    
                        
                    }
                    else
                    {
                        montoTotal = cantLlantas * 700;
                    textResultado.Text = "$" + montoTotal;
                    
                     
                    }
                }
                else
                {
                    file.WriteLine("Error " + c + ": El usuario " + nombreUs + " quiso ingresar {0} llantas, pero solo son permitidas entre 1 y 50 en cada compra...", cantLlantas);
                   MessageBox.Show("El limite de compra es entre 1 y 50 llantas...\nFavor de ingresar una cantidad permitida...\n Pulse cualquier tecla para continuar...","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                    c = c + 1;
                   

                }
            
            file.Close();
        }
    }
}
