﻿namespace WindowsFormsApplication1.vista
{
    partial class FormCondicionales
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormCondicionales));
            this.pictureFondo = new System.Windows.Forms.PictureBox();
            this.labelCondicionales = new System.Windows.Forms.Label();
            this.buttonLlantas = new System.Windows.Forms.Button();
            this.buttonEcuacionC = new System.Windows.Forms.Button();
            this.buttonVoC = new System.Windows.Forms.Button();
            this.buttonNombre = new System.Windows.Forms.Button();
            this.buttonMes = new System.Windows.Forms.Button();
            this.pictureHome = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureFondo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureHome)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureFondo
            // 
            this.pictureFondo.Image = ((System.Drawing.Image)(resources.GetObject("pictureFondo.Image")));
            this.pictureFondo.Location = new System.Drawing.Point(-4, 1);
            this.pictureFondo.Name = "pictureFondo";
            this.pictureFondo.Size = new System.Drawing.Size(404, 384);
            this.pictureFondo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureFondo.TabIndex = 0;
            this.pictureFondo.TabStop = false;
            // 
            // labelCondicionales
            // 
            this.labelCondicionales.AutoSize = true;
            this.labelCondicionales.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.labelCondicionales.Font = new System.Drawing.Font("Lucida Handwriting", 15.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCondicionales.Location = new System.Drawing.Point(94, 9);
            this.labelCondicionales.Name = "labelCondicionales";
            this.labelCondicionales.Size = new System.Drawing.Size(206, 27);
            this.labelCondicionales.TabIndex = 1;
            this.labelCondicionales.Text = "CONDICIONALES";
            this.labelCondicionales.Click += new System.EventHandler(this.label1_Click);
            // 
            // buttonLlantas
            // 
            this.buttonLlantas.Font = new System.Drawing.Font("Century Gothic", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonLlantas.Location = new System.Drawing.Point(76, 104);
            this.buttonLlantas.Name = "buttonLlantas";
            this.buttonLlantas.Size = new System.Drawing.Size(85, 31);
            this.buttonLlantas.TabIndex = 2;
            this.buttonLlantas.Text = "LLANTERA";
            this.buttonLlantas.UseVisualStyleBackColor = true;
            this.buttonLlantas.Click += new System.EventHandler(this.buttonLlantas_Click);
            // 
            // buttonEcuacionC
            // 
            this.buttonEcuacionC.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonEcuacionC.Location = new System.Drawing.Point(76, 182);
            this.buttonEcuacionC.Name = "buttonEcuacionC";
            this.buttonEcuacionC.Size = new System.Drawing.Size(85, 34);
            this.buttonEcuacionC.TabIndex = 3;
            this.buttonEcuacionC.Text = "ECUACIÓN CUADRÁTICA";
            this.buttonEcuacionC.UseVisualStyleBackColor = true;
            this.buttonEcuacionC.Click += new System.EventHandler(this.buttonEcuacionC_Click);
            // 
            // buttonVoC
            // 
            this.buttonVoC.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonVoC.Location = new System.Drawing.Point(168, 259);
            this.buttonVoC.Name = "buttonVoC";
            this.buttonVoC.Size = new System.Drawing.Size(85, 37);
            this.buttonVoC.TabIndex = 4;
            this.buttonVoC.Text = "VOCAL Ó CONSONANTE";
            this.buttonVoC.UseVisualStyleBackColor = true;
            this.buttonVoC.Click += new System.EventHandler(this.buttonVoC_Click);
            // 
            // buttonNombre
            // 
            this.buttonNombre.Location = new System.Drawing.Point(253, 104);
            this.buttonNombre.Name = "buttonNombre";
            this.buttonNombre.Size = new System.Drawing.Size(85, 31);
            this.buttonNombre.TabIndex = 5;
            this.buttonNombre.Text = "NOMBRES";
            this.buttonNombre.UseVisualStyleBackColor = true;
            this.buttonNombre.Click += new System.EventHandler(this.buttonNombre_Click);
            // 
            // buttonMes
            // 
            this.buttonMes.Location = new System.Drawing.Point(253, 182);
            this.buttonMes.Name = "buttonMes";
            this.buttonMes.Size = new System.Drawing.Size(85, 34);
            this.buttonMes.TabIndex = 6;
            this.buttonMes.Text = "MESES";
            this.buttonMes.UseVisualStyleBackColor = true;
            this.buttonMes.Click += new System.EventHandler(this.buttonMes_Click);
            // 
            // pictureHome
            // 
            this.pictureHome.Image = ((System.Drawing.Image)(resources.GetObject("pictureHome.Image")));
            this.pictureHome.Location = new System.Drawing.Point(342, 335);
            this.pictureHome.Name = "pictureHome";
            this.pictureHome.Size = new System.Drawing.Size(58, 50);
            this.pictureHome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureHome.TabIndex = 8;
            this.pictureHome.TabStop = false;
            this.pictureHome.Click += new System.EventHandler(this.pictureHome_Click);
            // 
            // FormCondicionales
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(401, 386);
            this.ControlBox = false;
            this.Controls.Add(this.pictureHome);
            this.Controls.Add(this.buttonMes);
            this.Controls.Add(this.buttonNombre);
            this.Controls.Add(this.buttonVoC);
            this.Controls.Add(this.buttonEcuacionC);
            this.Controls.Add(this.buttonLlantas);
            this.Controls.Add(this.labelCondicionales);
            this.Controls.Add(this.pictureFondo);
            this.Name = "FormCondicionales";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormCondicionales";
            ((System.ComponentModel.ISupportInitialize)(this.pictureFondo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureHome)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureFondo;
        private System.Windows.Forms.Label labelCondicionales;
        private System.Windows.Forms.Button buttonLlantas;
        private System.Windows.Forms.Button buttonEcuacionC;
        private System.Windows.Forms.Button buttonVoC;
        private System.Windows.Forms.Button buttonNombre;
        private System.Windows.Forms.Button buttonMes;
        private System.Windows.Forms.PictureBox pictureHome;
    }
}