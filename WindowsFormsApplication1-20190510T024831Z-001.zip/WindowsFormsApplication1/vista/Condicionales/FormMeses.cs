﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1.vista.Condicionales
{
    public partial class FormMeses : Form
    {
        public FormMeses()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Calcular_Click(object sender, EventArgs e)
        {
            int numero;
            numero = Int16.Parse(textNumero.Text);
            if (numero < 1 || numero > 12)
            {



                MessageBox.Show("Elegiste un numero incorrecto..Los meses solo hay entre 1 y 12...Vuelvelo a escribir...", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textNumero.Text = "";

            }
            else
            {

                switch (numero)
                {
                    case 1:
                        textResult.Text = "Enero es el primer mes del año en el calendario gregoriano y tiene 31 días.";
                        break;
                    case 2:
                        textResult.Text = "Febrero es el segundo mes del año en el calendario gregoriano. Tiene 28 días y 29 en los años bisiestos.";
                        break;
                    case 3:
                        textResult.Text = "Marzo es el tercer mes del año en el calendario gregoriano y tiene 31 días.";
                        break;
                    case 4:
                        textResult.Text = "Abril es el cuarto mes del año y es uno de los cuatro meses que tienen 30 días.";
                        break;
                    case 5:
                        textResult.Text = "Mayo es el quinto mes del año en el calendario gregoriano y tiene 31 días.";
                        break;
                    case 6:
                        textResult.Text = "Junio es el sexto mes del año en el Calendario Gregoriano y tiene 30 días.";
                        break;
                    case 7:
                        textResult.Text = "Julio es el séptimo mes del año en el calendario gregoriano y tiene 31 días.";
                        break;
                    case 8:
                        textResult.Text = "Agosto es el octavo mes del año en el calendario gregoriano y tiene 31 días.";
                        break;
                    case 9:
                        textResult.Text = "Septiembre es el noveno mes del año en el calendario gregoriano y tiene 30 días";
                        break;
                    case 10:
                        textResult.Text = "Octubre es el décimo mes del año en el calendario gregoriano y tiene 31 días.";
                        break;
                    case 11:
                        textResult.Text = "Noviembre es el undécimo y penúltimo mes del año en el calendario gregoriano";
                        break;
                    case 12:
                        textResult.Text = "Diciembre es el duodécimo y último mes del año en el calendario gregoriano y tiene 31 días.";
                        break;
                    default:
                        break;

                }
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Program.formaCondicionales.Show();
            Hide();
        }
    }
}
