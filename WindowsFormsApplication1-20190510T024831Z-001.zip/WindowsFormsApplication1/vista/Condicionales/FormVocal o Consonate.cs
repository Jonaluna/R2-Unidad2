﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1.vista
{
    public partial class FormVocal_o_Consonate : Form
    {
        public FormVocal_o_Consonate()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBoxHome_Click(object sender, EventArgs e)
        {
            Program.formaCondicionales.Show();
            Hide();
        }

        private void Calcular_Click(object sender, EventArgs e)
        {
            string nombre;
            int largo;
            
                
                nombre = textNombre.Text;
                largo = nombre.Length;
                if (largo < 3 || largo > 30)
                {
                    MessageBox.Show("El rango de caracteres de nombre son entre 3 y 30...\n vuelvelo a escribir...","ERROR",MessageBoxButtons.OK,MessageBoxIcon.Error);
                }
           


            String caracter = nombre.Substring(0, 1);
            String caracter1 = caracter.ToUpper();

            if (caracter1.Equals("A") || caracter1.Equals("E") || caracter1.Equals("I") || caracter1.Equals("O") || caracter1.Equals("U") || caracter1.Equals("Á") || caracter1.Equals("É") || caracter1.Equals("Í") || caracter1.Equals("Ó") || caracter1.Equals("Ú"))
            {
                textResultado.Text="El NOMBRE: " + nombre + " inicia con una VOCAL";
                
            }
            else
            {
                textResultado.Text = "El NOMBRE: " + nombre + " inicia con una CONSONANTE";
               
            }
        }
    }
}
