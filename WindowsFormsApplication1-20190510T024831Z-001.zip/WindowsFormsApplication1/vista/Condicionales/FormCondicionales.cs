﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1.vista
{
    public partial class FormCondicionales : Form
    {
        public FormCondicionales()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void buttonLlantas_Click(object sender, EventArgs e)
        {
            Program.formaLlantas.Show();
            Hide();
        }

        private void buttonNombre_Click(object sender, EventArgs e)
        {
            Program.formaNomMayu.Show();
            Hide();
        }

        private void buttonEcuacionC_Click(object sender, EventArgs e)
        {
            Program.formaEcuCuadra.Show();
            Hide();
        }

        private void buttonMes_Click(object sender, EventArgs e)
        {
            Program.formaMeses.Show();
            Hide();
        }

        private void buttonVoC_Click(object sender, EventArgs e)
        {
            Program.formaVocalConsona.Show();
            Hide();
        }

     

        private void pictureHome_Click(object sender, EventArgs e)
        {
            Program.formaMenu.Show();
            Hide();
        }
    }
}
