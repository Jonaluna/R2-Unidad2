﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1.vista
{
    public partial class FormNombreMayus : Form
    {
        public FormNombreMayus()
        {
            InitializeComponent();
        }

        private void labelResultado_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Calcular_Click(object sender, EventArgs e)
        {
            string doc, texto;
            doc = textRuta.Text;

           
                StreamReader file = new StreamReader(doc);
                texto = file.ReadLine();
                String caracter = texto.Substring(0, 1);


                if (caracter.Equals(caracter.ToUpper()))
                {
                   textResultado.Text= "El NOMBRE: " + texto + " inicia con MAYUSCULA";
                    
                }
                else
                {
                    textResultado.Text = "El NOMBRE: " + texto + " inicia con MINUSCULA ******" + texto.ToUpper() + "******";
                    
                }
           
               
                
            

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Program.formaCondicionales.Show();
            Hide();
        }
    }
}
