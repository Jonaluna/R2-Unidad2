﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1.vista
{
    public partial class FormEcuacionCuadratica : Form
    {
        public FormEcuacionCuadratica()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Program.formaCondicionales.Show();
            Hide();
        }

        private void Calcular_Click(object sender, EventArgs e)
        {
            double a, b, c, x1, x2, raices;
            a = Double.Parse(textBoxA.Text);

            b = Double.Parse(textBoxB.Text);

            c = Double.Parse(textBoxC.Text);
            if (a == 0)
            {
                MessageBox.Show("El valor de -a- debe ser dierente de 0...\n vuelvelo a escribir...", "Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            else
            {
                

                raices = (b * b - (4 * a * c));

                x1 = (-b + Math.Sqrt(Math.Abs(raices))) / 2 * a;
                x2 = (-b - Math.Sqrt(Math.Abs(raices))) / 2 * a;
                if (raices < 0)
                {
                    textX1.Text= x1 + " i";
                    textX2.Text =x2 + " i";
                    
                }
                else
                {
                    textX1.Text = "" + x1;
                    textX2.Text = "" + x2;
                }
            }
        }
    }
}
