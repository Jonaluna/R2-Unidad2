﻿namespace WindowsFormsApplication1.vista
{
    partial class FormaMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormaMenu));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.Condicionales = new System.Windows.Forms.Button();
            this.Ciclos = new System.Windows.Forms.Button();
            this.Funciones = new System.Windows.Forms.Button();
            this.Arreglos = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureExit = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureExit)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(408, 466);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.button1.Font = new System.Drawing.Font("Lucida Calligraphy", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(42, 100);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(148, 59);
            this.button1.TabIndex = 1;
            this.button1.Text = "SECUENCIALES";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Condicionales
            // 
            this.Condicionales.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.Condicionales.Font = new System.Drawing.Font("Lucida Calligraphy", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Condicionales.Location = new System.Drawing.Point(42, 185);
            this.Condicionales.Name = "Condicionales";
            this.Condicionales.Size = new System.Drawing.Size(148, 55);
            this.Condicionales.TabIndex = 2;
            this.Condicionales.Text = "CONDICIONALES";
            this.Condicionales.UseVisualStyleBackColor = false;
            this.Condicionales.Click += new System.EventHandler(this.Condicionales_Click);
            // 
            // Ciclos
            // 
            this.Ciclos.BackColor = System.Drawing.SystemColors.Info;
            this.Ciclos.Font = new System.Drawing.Font("Lucida Calligraphy", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ciclos.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Ciclos.Location = new System.Drawing.Point(250, 100);
            this.Ciclos.Name = "Ciclos";
            this.Ciclos.Size = new System.Drawing.Size(126, 59);
            this.Ciclos.TabIndex = 3;
            this.Ciclos.Text = "CICLOS";
            this.Ciclos.UseVisualStyleBackColor = false;
            this.Ciclos.Click += new System.EventHandler(this.Ciclos_Click);
            // 
            // Funciones
            // 
            this.Funciones.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Funciones.Font = new System.Drawing.Font("Lucida Calligraphy", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Funciones.Location = new System.Drawing.Point(250, 185);
            this.Funciones.Name = "Funciones";
            this.Funciones.Size = new System.Drawing.Size(126, 55);
            this.Funciones.TabIndex = 4;
            this.Funciones.Text = "FUNCIONES";
            this.Funciones.UseVisualStyleBackColor = false;
            this.Funciones.Click += new System.EventHandler(this.Funciones_Click);
            // 
            // Arreglos
            // 
            this.Arreglos.BackColor = System.Drawing.Color.MistyRose;
            this.Arreglos.Font = new System.Drawing.Font("Lucida Calligraphy", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Arreglos.Location = new System.Drawing.Point(151, 269);
            this.Arreglos.Name = "Arreglos";
            this.Arreglos.Size = new System.Drawing.Size(122, 54);
            this.Arreglos.TabIndex = 5;
            this.Arreglos.Text = "ARREGLOS";
            this.Arreglos.UseVisualStyleBackColor = false;
            this.Arreglos.Click += new System.EventHandler(this.Arreglos_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.PowderBlue;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(90, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(240, 24);
            this.label1.TabIndex = 6;
            this.label1.Text = "MENÚ DE PROGRAMAS";
            // 
            // pictureExit
            // 
            this.pictureExit.Image = ((System.Drawing.Image)(resources.GetObject("pictureExit.Image")));
            this.pictureExit.Location = new System.Drawing.Point(318, 407);
            this.pictureExit.Name = "pictureExit";
            this.pictureExit.Size = new System.Drawing.Size(90, 59);
            this.pictureExit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureExit.TabIndex = 7;
            this.pictureExit.TabStop = false;
            this.pictureExit.Click += new System.EventHandler(this.pictureExit_Click);
            // 
            // FormaMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(408, 466);
            this.ControlBox = false;
            this.Controls.Add(this.pictureExit);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Arreglos);
            this.Controls.Add(this.Funciones);
            this.Controls.Add(this.Ciclos);
            this.Controls.Add(this.Condicionales);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "FormaMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureExit)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button Condicionales;
        private System.Windows.Forms.Button Ciclos;
        private System.Windows.Forms.Button Funciones;
        private System.Windows.Forms.Button Arreglos;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureExit;
    }
}