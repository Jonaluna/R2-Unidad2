﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using WindowsFormsApplication1.vista;
using WindowsFormsApplication1.vista.Ciclos;
using WindowsFormsApplication1.vista.Condicionales;
using WindowsFormsApplication1.vista.Funciones;

namespace WindowsFormsApplication1
{
    static class Program
    {

        public static FormaMenu formaMenu = null;
        public static FormArreglos formaArreglos = null;
        /*Arreglos*/public static FormMediaAritmetica formaMediaAritmetica = null;
        /*Arreglos*/public static FormNombres formaNombres = null;
        /*Arreglos*/public static FormNum_May_Men formaNumMayMen = null;
        /*Arreglos*/public static FormVocalConsonante formaVocalCons = null;
        public static FormCiclos formaCiclos = null;
        /*Ciclos*/public static FormEstudiantes_e_Institucion formaEstudeInstitu = null;
        /*Ciclos*/public static FormEstudiantes_y_Calificaciones formaEstudyClaif = null;
        /*Ciclos*/public static FormEstudiantesCarrera formaEstudCarre= null;
        /*Ciclos*/public static FormListaEstudiantes formaListaEstud= null;
        /*Ciclos*/public static FormListaNombres formaListaNombres = null;
        
        /*Ciclos*/public static FormNomEstudiantes formaNomEstudi = null;
        /*Ciclos*/public static FormSaludo10 formaSaludo10 = null;
        /*Ciclos*/public static FormSaludos formaSaludos = null;
       
        /*Ciclos*/public static FormSaludoSI formaSaludoSI = null;
        public static FormCondicionales formaCondicionales = null;
        /*Condicionales*/public static FormEcuacionCuadratica formaEcuCuadra = null;
        /*Condicionales*/public static FormLlantas formaLlantas = null;
        /*Condicionales*/public static FormMeses formaMeses = null;
    
        /*Condicionales*/public static FormNombreMayus formaNomMayu = null;
        /*Condicionales*/public static FormVocal_o_Consonate formaVocalConsona = null;
        public static FormFunciones formaFunciones = null;
        /*Funciones*/public static FormCombinatorios formaCombinatorio = null;
        /*Funciones*/public static FormNumeroAmigo formaNumAmigo = null;
        /*Funciones*/public static FormNumeroPerfecto formaNumPerfecto = null;
        /*Funciones*/public static FormParametros formaParametros = null;
         public static FormSecuenciales formaSecuenciales = null;
        /*Secuenciales*/public static FormDivisas formaDivisas = null;
        /*Secuenciales*/public static FormEcuacionC formaECuadra = null;
        /*Secuenciales*/public static FormFCM formaFCM = null;
        /*Secuenciales*/public static FormGanancias formaGanancia = null;
        /*Secuenciales*/public static FormHipotenusa formaHipote = null;
        /*Secuenciales*/public static FormIMC formaIMC = null;
        /*Secuenciales*/public static FormPresupuesto formaPresupuesto = null;
        /*Secuenciales*/public static FormSalario formaSalario = null;
        /*Secuenciales*/public static FormVAbsoluto formaValAbsol = null;
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            formaMenu = new FormaMenu();
            formaArreglos = new FormArreglos();
            formaEstudeInstitu = new FormEstudiantes_e_Institucion();
            formaEstudyClaif = new FormEstudiantes_y_Calificaciones();
            formaEstudCarre = new FormEstudiantesCarrera();
            formaListaEstud = new FormListaEstudiantes();
            formaEstudyClaif = new FormEstudiantes_y_Calificaciones();
            formaListaNombres = new FormListaNombres();
            formaMediaAritmetica = new FormMediaAritmetica();
            formaNomEstudi = new FormNomEstudiantes();
            formaSaludo10 = new FormSaludo10();
            formaSaludoSI = new FormSaludoSI();
     
            formaSaludos = new FormSaludos();
            formaCombinatorio = new FormCombinatorios();
            formaEcuCuadra = new FormEcuacionCuadratica();
            formaLlantas = new FormLlantas();
            formaMeses = new FormMeses();
            formaNombres = new FormNombres();
            formaNumMayMen = new FormNum_May_Men();
            formaNomMayu = new FormNombreMayus();
            formaVocalConsona = new FormVocal_o_Consonate();
            formaNumAmigo = new FormNumeroAmigo();
            formaNumPerfecto = new FormNumeroPerfecto();
            formaParametros = new FormParametros();
            formaDivisas = new FormDivisas();
            formaECuadra = new FormEcuacionC();
            formaFCM = new FormFCM();
            formaGanancia = new FormGanancias();
            formaHipote = new FormHipotenusa();
            formaIMC = new FormIMC();
            formaPresupuesto = new FormPresupuesto();
            formaSalario = new FormSalario();
            formaValAbsol = new FormVAbsoluto();
            formaCiclos = new FormCiclos();
            formaCondicionales = new FormCondicionales();
            formaFunciones = new FormFunciones();
            formaSecuenciales = new FormSecuenciales();
            formaVocalCons = new FormVocalConsonante();
            Application.Run(new FormaMenu());
        }
    }
}
